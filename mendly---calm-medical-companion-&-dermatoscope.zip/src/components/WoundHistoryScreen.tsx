import React, { useState } from 'react';
import { ScreenId, WoundRecord } from '../types';

interface WoundHistoryScreenProps {
  wounds: WoundRecord[];
  onSelectWound: (wound: WoundRecord) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const WoundHistoryScreen: React.FC<WoundHistoryScreenProps> = ({
  wounds,
  onSelectWound,
  onNavigate,
}) => {
  const [filter, setFilter] = useState<'All' | 'Healing' | 'Monitoring'>('All');

  const filteredWounds = wounds.filter((w) => {
    if (filter === 'All') return true;
    return w.status === filter;
  });

  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-24 pt-2 space-y-4">
      {/* Header bar info */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[22px] font-extrabold text-[#0a2342] tracking-tight">
            Wound &amp; Scan History
          </h2>
          <p className="text-[13px] text-[#414754]">
            Tracking healing trajectories and dermatoscopic scans
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('scanner-live-view')}
          className="px-3.5 py-1.5 rounded-full bg-[#0a6fe8] text-white text-[13px] font-bold shadow-xs hover:bg-[#0057bb] active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[17px]">add</span>
          <span>Scan</span>
        </button>
      </div>

      {/* Filter Segmented Control */}
      <div className="flex items-center gap-1.5 p-1 bg-[#ebeef2] rounded-xl">
        {(['All', 'Healing', 'Monitoring'] as const).map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setFilter(cat)}
            className={`flex-1 py-1.5 rounded-lg text-[13px] font-bold transition-all text-center ${
              filter === cat
                ? 'bg-white text-[#0a6fe8] shadow-xs'
                : 'text-[#414754] hover:text-[#0a2342]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* List of Wounds */}
      <div className="space-y-3">
        {filteredWounds.map((wound) => (
          <article
            key={wound.id}
            onClick={() => onSelectWound(wound)}
            className="bg-white rounded-2xl p-4 shadow-xs border border-[#e2e8f0]/80 hover:shadow-md hover:border-[#0a6fe8]/40 transition-all cursor-pointer active:scale-[0.99] space-y-3"
          >
            <div className="flex items-start gap-3.5">
              <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-[#ebeef2] border border-[#e2e8f0]">
                <img
                  src={wound.imageUrl}
                  alt={wound.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h3 className="text-[16px] font-bold text-[#0a2342] truncate">{wound.title}</h3>
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[12px] font-bold ${
                      wound.status === 'Healing' || wound.healedPercent > 70
                        ? 'bg-[#e8f8f2] text-[#0b7b56]'
                        : 'bg-[#fef3c7] text-[#b45309]'
                    }`}
                  >
                    {wound.healedPercent}% healed
                  </span>
                </div>

                <p className="text-[12px] text-[#414754] mt-0.5">
                  {wound.dimensions} • {wound.depthType} • {wound.timestamp}
                </p>

                <p className="text-[12px] text-[#414754] line-clamp-1 mt-1">
                  {wound.clinicalNotes}
                </p>
              </div>
            </div>

            {/* Healing Progress Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-semibold text-[#414754]">
                <span>Healing Progression</span>
                <span>{wound.healedPercent}%</span>
              </div>
              <div className="w-full bg-[#ebeef2] h-2 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full bg-[#0a6fe8] transition-all duration-500"
                  style={{ width: `${wound.healedPercent}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-[#f1f4f8] text-[12px]">
              <span className="text-[#0a6fe8] font-bold flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">visibility</span>
                Inspect Clinical Analysis
              </span>
              <span className="text-[#414754] font-medium">{wound.severityTier}</span>
            </div>
          </article>
        ))}

        {filteredWounds.length === 0 && (
          <div className="p-8 text-center text-[#414754] bg-white rounded-2xl border border-[#e2e8f0]">
            <span className="material-symbols-outlined text-[36px] text-[#727785]">
              healing
            </span>
            <p className="text-[15px] font-bold mt-2">No wounds in this category</p>
            <p className="text-[13px] mt-1">Capture a new scan to monitor healing.</p>
          </div>
        )}
      </div>
    </div>
  );
};
