import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';

interface NurseAiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenEmergency: () => void;
}

interface Message {
  id: string;
  sender: 'nurse' | 'user';
  text: string;
  timestamp: string;
}

export const NurseAiModal: React.FC<NurseAiModalProps> = ({ isOpen, onClose, onOpenEmergency }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'nurse',
      text: "Hello! I'm your Mendly Nurse AI. I've reviewed your latest dermatoscope scan of the shallow abrasion. How are you feeling right now?",
      timestamp: 'Just now',
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  if (!isOpen) return null;

  const quickPrompts = [
    'Is my wound showing signs of infection?',
    'How often should I change the bandage?',
    'Can I shower with this abrasion?',
    'When should I see a doctor?',
  ];

  const handleSend = (textToSend?: string) => {
    const query = textToSend || inputVal;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query.trim(),
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputVal('');
    setIsTyping(true);

    setTimeout(() => {
      let reply = '';
      const q = query.toLowerCase();

      if (q.includes('infect') || q.includes('red') || q.includes('pus')) {
        reply =
          'Signs of infection usually appear 24-48 hours after injury. Watch for expanding redness beyond 1 cm, localized warmth, yellow or cloudy discharge, or throbbing pain. Your current scan shows clean margins with minimal peripheral erythema, which is standard for healthy inflammatory stage 1 healing!';
      } else if (q.includes('bandage') || q.includes('dressing') || q.includes('change')) {
        reply =
          'Change your adhesive strip or breathable dressing once every 24 hours, or immediately if it gets wet or soiled. Keep a thin dab of pure petroleum jelly on it to keep the cellular growth bed moist.';
      } else if (q.includes('shower') || q.includes('water') || q.includes('bath')) {
        reply =
          'You can take a brief shower after 24 hours! Avoid soaking in a hot tub or bath. Let water wash gently over the area without scrubbing, and pat dry gently with a clean towel before applying fresh ointment.';
      } else if (q.includes('doctor') || q.includes('hospital') || q.includes('urgent')) {
        reply =
          'Seek professional medical care if bleeding does not stop after 10 minutes of direct pressure, if you haven’t had a tetanus shot in 10 years, if the wound is deeper than 0.5 cm, or if red streaks radiate outward.';
      } else {
        reply =
          'Based on the Mendly high-precision 20x scan, your shallow abrasion is in the normal epidermal re-epithelialization phase. Keep it clean, protect it from friction, and drink plenty of water to support collagen synthesis!';
      }

      const nurseMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'nurse',
        text: reply,
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, nurseMsg]);
      setIsTyping(false);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[85vh] h-[650px] flex flex-col shadow-2xl overflow-hidden border border-[#e2e8f0]">
        {/* Header */}
        <div className="px-5 py-4 bg-[#f7fafe] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={ASSETS.avatar}
                alt="Nurse Avatar"
                className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-xs"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#10b981] border-2 border-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-[16px] font-bold text-[#0a2342]">Mendly Nurse AI</h3>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#c0d5fd] text-[#004494] font-bold">
                  Clinical Triage
                </span>
              </div>
              <p className="text-[12px] text-[#414754]">Empathetic First-Aid Guidance</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#ebeef2] hover:bg-[#e0e3e7] text-[#0a2342] flex items-center justify-center cursor-pointer transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Chat Feed */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-[#f7fafe]/40">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-[14px] leading-relaxed shadow-xs ${
                  msg.sender === 'user'
                    ? 'bg-[#0a6fe8] text-white rounded-br-xs'
                    : 'bg-white text-[#0a2342] border border-[#e2e8f0] rounded-bl-xs'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white rounded-2xl px-4 py-2.5 text-[#414754] text-[13px] border border-[#e2e8f0] rounded-bl-xs flex items-center gap-1.5 shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0a6fe8] animate-bounce" />
                <span
                  className="w-1.5 h-1.5 rounded-full bg-[#0a6fe8] animate-bounce"
                  style={{ animationDelay: '0.2s' }}
                />
                <span
                  className="w-1.5 h-1.5 rounded-full bg-[#0a6fe8] animate-bounce"
                  style={{ animationDelay: '0.4s' }}
                />
                <span className="text-[12px] ml-1 text-[#414754]">Nurse is reviewing...</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 bg-white border-t border-[#f1f4f8] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(prompt)}
              className="text-[12px] font-semibold bg-[#f1f4f8] hover:bg-[#c0d5fd]/40 text-[#0a2342] px-3 py-1.5 rounded-full whitespace-nowrap active:scale-95 transition-all border border-[#e2e8f0] cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-[#e2e8f0] flex items-center gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your wound care question..."
            className="flex-1 bg-[#f1f4f8] rounded-full px-4 py-2.5 text-[14px] text-[#0a2342] border border-[#e2e8f0] focus:border-[#0a6fe8] focus:bg-white outline-none transition-colors"
          />
          <button
            type="button"
            onClick={() => handleSend()}
            className="w-11 h-11 rounded-full bg-[#0a6fe8] hover:bg-[#0057bb] text-white flex items-center justify-center shrink-0 shadow-md active:scale-95 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">send</span>
          </button>
        </div>

        {/* Footer Emergency Disclaimer */}
        <div className="bg-[#ffdad6]/40 px-4 py-2 border-t border-[#ffb4ac]/30 flex items-center justify-between text-[12px]">
          <span className="text-[#93000a] font-medium truncate">
            Not for critical medical emergencies
          </span>
          <button
            type="button"
            onClick={onOpenEmergency}
            className="text-[#e0403a] font-bold hover:underline shrink-0 ml-2"
          >
            Call 1669
          </button>
        </div>
      </div>
    </div>
  );
};
