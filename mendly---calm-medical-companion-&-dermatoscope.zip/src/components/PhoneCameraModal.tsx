import React, { useRef, useState } from 'react';
import { ASSETS } from '../data/mockData';
import { WoundRecord } from '../types';

interface PhoneCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalysisComplete: (wound: WoundRecord) => void;
}

export const PhoneCameraModal: React.FC<PhoneCameraModalProps> = ({
  isOpen,
  onClose,
  onAnalysisComplete,
}) => {
  const [selectedImage, setSelectedImage] = useState<string>(ASSETS.woundDermatoscope);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStage, setAnalysisStage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSelectedImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartAnalysis = () => {
    setIsAnalyzing(true);
    setAnalysisStage('Enhancing 20x optical macro contrast...');

    setTimeout(() => {
      setAnalysisStage('Calibrating wound dimensions & depth metrics...');
    }, 700);

    setTimeout(() => {
      setAnalysisStage('Querying Mendly DermatoAI pathology library...');
    }, 1400);

    setTimeout(() => {
      setIsAnalyzing(false);

      const analyzedWound: WoundRecord = {
        id: `wound-${Date.now()}`,
        title: 'Shallow Abrasion',
        category: 'Abrasion',
        matchScore: 98,
        depthType: 'Epidermal',
        dimensions: '14 × 6 mm',
        area: '~84 mm²',
        depth: '<0.5 mm depth',
        severityTier: 'Tier 1/3',
        severityLabel: 'Minor Wound — Safe to treat at home',
        timestamp: 'Just now',
        healedPercent: 88,
        imageUrl: selectedImage,
        clinicalNotes:
          'Capillary edges clean, slight peripheral erythema, bleeding controlled.',
        status: 'Healing',
        treatmentSteps: [
          {
            id: 1,
            title: 'Clean your hands thoroughly',
            description:
              'Wash hands with warm water and soap for at least 20 seconds before touching the abrasion to prevent infection.',
            completed: false,
            hasTimer: true,
            timerSeconds: 20,
            timerLabel: 'Handwash Timer',
          },
          {
            id: 2,
            title: 'Rinse the cut gently',
            description:
              'Hold under gentle, lukewarm tap water to dislodge particulate debris. Avoid harsh alcohol, iodine, or hydrogen peroxide on fresh tissue.',
            completed: false,
          },
          {
            id: 3,
            title: 'Apply gentle steady pressure',
            description:
              'Hold a clean gauze or lint-free pad over the cut for 3 continuous minutes until capillary ooze fully coagulates.',
            completed: false,
            hasTimer: true,
            timerSeconds: 180,
            timerLabel: '3-Min Hold Timer',
          },
          {
            id: 4,
            title: 'Protect with a breathable dressing',
            description:
              'Apply a thin dab of petroleum jelly and seal with a sterile fingertip adhesive strip. Replace daily or whenever wet.',
            completed: false,
          },
        ],
      };

      onAnalysisComplete(analyzedWound);
    }, 2100);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#e2e8f0] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-[#f7fafe] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[22px] text-[#0a6fe8]">
              photo_camera
            </span>
            <h3 className="text-[17px] font-bold text-[#0a2342]">Phone Camera Triage</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#ebeef2] text-[#0a2342] flex items-center justify-center hover:bg-[#e0e3e7] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Viewfinder Preview */}
        <div className="p-5 flex flex-col items-center space-y-4">
          <div className="relative w-64 h-64 rounded-2xl overflow-hidden bg-black shadow-inner border-2 border-[#0a6fe8] flex items-center justify-center">
            <img
              src={selectedImage}
              alt="Wound to analyze"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Camera reticle overlay */}
            <div className="absolute inset-0 pointer-events-none border border-white/40 m-4 rounded-xl flex items-center justify-center">
              <div className="w-12 h-12 border-2 border-dashed border-[#0a6fe8] rounded-full animate-pulse" />
            </div>

            {isAnalyzing && (
              <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-4 text-center z-20">
                <div className="w-12 h-12 border-4 border-[#0a6fe8] border-t-transparent rounded-full animate-spin mb-3" />
                <span className="text-[14px] font-bold text-white leading-tight">
                  DermatoAI Analyzing...
                </span>
                <span className="text-[12px] text-white/80 mt-1">{analysisStage}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3.5 py-1.5 rounded-full bg-[#ebeef2] hover:bg-[#e0e3e7] text-[#0a2342] text-[12px] font-bold flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">upload</span>
              <span>Upload Photo</span>
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />

            <button
              type="button"
              onClick={() => setSelectedImage(ASSETS.recentSnapshot)}
              className="px-3.5 py-1.5 rounded-full bg-[#ebeef2] hover:bg-[#e0e3e7] text-[#0a2342] text-[12px] font-bold flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">autorenew</span>
              <span>Sample 2</span>
            </button>
          </div>

          <p className="text-[12px] text-[#414754] text-center leading-relaxed">
            Align the affected skin area inside the reticle under direct lighting.
          </p>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f7fafe] border-t border-[#e2e8f0] flex flex-col gap-2">
          <button
            type="button"
            onClick={handleStartAnalysis}
            disabled={isAnalyzing}
            className="w-full py-3.5 bg-[#0a6fe8] hover:bg-[#0057bb] active:scale-95 text-white font-bold text-[15px] rounded-full transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-[20px]">biotech</span>
            <span>Run DermatoAI Analysis</span>
          </button>
        </div>
      </div>
    </div>
  );
};
