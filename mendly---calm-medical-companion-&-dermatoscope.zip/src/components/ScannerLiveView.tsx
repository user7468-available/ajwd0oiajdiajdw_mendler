import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';
import { DeviceState, ScreenId } from '../types';

interface ScannerLiveViewProps {
  deviceState: DeviceState;
  onCapture: () => void;
  onBack: () => void;
  onOpenEmergency: () => void;
  onNavigate: (screen: ScreenId) => void;
  onUpdateDeviceState: (updates: Partial<DeviceState>) => void;
}

export const ScannerLiveView: React.FC<ScannerLiveViewProps> = ({
  deviceState,
  onCapture,
  onBack,
  onOpenEmergency,
  onNavigate,
  onUpdateDeviceState,
}) => {
  const [zoomLevel, setZoomLevel] = useState<'10x' | '20x' | '40x'>(
    deviceState.opticalMagnification || '20x'
  );
  const [isFlashing, setIsFlashing] = useState(false);
  const [focusDistance, setFocusDistance] = useState('1.5 cm');

  const handleToggleLed = () => {
    onUpdateDeviceState({ isLedOn: !deviceState.isLedOn });
  };

  const handleCycleBrightness = () => {
    const nextBrightness: Record<number, 30 | 65 | 100> = {
      30: 65,
      65: 100,
      100: 30,
    };
    onUpdateDeviceState({
      ringLightBrightness: nextBrightness[deviceState.ringLightBrightness] || 100,
      isLedOn: true,
    });
  };

  const handleTriggerCapture = () => {
    // Shutter flash effect
    setIsFlashing(true);
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(40);
      } catch (e) {
        // ignore vibrate restrictions
      }
    }
    setTimeout(() => {
      setIsFlashing(false);
      onCapture();
    }, 380);
  };

  const getZoomScaleClass = () => {
    switch (zoomLevel) {
      case '10x':
        return 'scale-95';
      case '20x':
        return 'scale-110';
      case '40x':
        return 'scale-135';
      default:
        return 'scale-110';
    }
  };

  return (
    <div className="relative w-full max-w-xl mx-auto min-h-screen flex flex-col justify-between bg-[#f7fafe] select-none pb-6">
      {/* Top Floating App Bar */}
      <div className="flex items-center justify-between px-4 sm:px-5 py-3 z-30 pt-safe">
        {/* Exit Live View Button */}
        <button
          type="button"
          aria-label="Exit live view"
          onClick={onBack}
          className="w-12 h-12 rounded-full bg-[#2d3134]/90 backdrop-blur-md text-[#eef1f5] flex items-center justify-center shadow-md active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined text-[24px]">arrow_back</span>
        </button>

        {/* Scanner Status Capsule */}
        <div className="flex items-center gap-2 bg-[#2d3134]/90 backdrop-blur-md px-4 py-2 rounded-full shadow-md text-[#eef1f5]">
          <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] animate-pulse" />
          <span className="text-[13px] font-semibold tracking-wide">Mendly Live</span>
          <span className="text-[#c1c6d6] text-[12px]">•</span>
          <span className="text-[13px] font-medium flex items-center gap-1">
            <span className="material-symbols-outlined text-[16px] text-[#10b981]">
              battery_5_bar
            </span>
            {deviceState.battery}%
          </span>
        </div>

        {/* Ring Light Illumination Toggle Button */}
        <button
          type="button"
          aria-pressed={deviceState.isLedOn}
          onClick={handleToggleLed}
          className="h-12 px-3.5 rounded-full bg-[#2d3134]/90 backdrop-blur-md text-[#eef1f5] flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <span
            className={`material-symbols-outlined text-[22px] transition-colors ${
              deviceState.isLedOn ? 'text-amber-300' : 'text-[#727785]'
            }`}
            style={deviceState.isLedOn ? { fontVariationSettings: "'FILL' 1" } : undefined}
          >
            flare
          </span>
          <span className="text-[12px] font-bold text-[#eef1f5]">
            {deviceState.isLedOn ? 'LED ON' : 'LED OFF'}
          </span>
        </button>
      </div>

      {/* Central Dermatoscope Microscope Viewport */}
      <div className="relative w-full aspect-square max-w-[390px] mx-auto px-4 flex items-center justify-center my-2">
        {/* Outer Optical Housing Ring */}
        <div className="relative w-full aspect-square rounded-full overflow-hidden shadow-2xl bg-[#2d3134] flex items-center justify-center border-4 border-[#2d3134]">
          {/* Live Video Feed from Mendly Handheld Scanner */}
          <img
            alt="Microscope live skin view"
            className={`w-full h-full object-cover select-none pointer-events-none transition-transform duration-300 ${getZoomScaleClass()}`}
            src={ASSETS.woundDermatoscope}
            referrerPolicy="no-referrer"
          />

          {/* High-Intensity Clinical Ring-Light Diffusion Scrim */}
          <div
            className={`absolute inset-0 rounded-full pointer-events-none transition-opacity duration-300 ${
              deviceState.isLedOn
                ? 'shadow-[inset_0_0_40px_14px_rgba(255,255,255,0.75)] opacity-100'
                : 'shadow-[inset_0_0_40px_14px_rgba(0,0,0,0.75)] opacity-20'
            }`}
          />

          {/* Flash Effect on capture */}
          {isFlashing && (
            <div className="absolute inset-0 bg-white z-50 pointer-events-none rounded-full animate-fade-out opacity-95 transition-opacity" />
          )}

          {/* Medical Dermatoscope Reticle & Polarized Lens Overlays */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-10"
            fill="none"
            viewBox="0 0 400 400"
          >
            {/* Circular Calibration Rim */}
            <circle
              cx="200"
              cy="200"
              r="185"
              stroke="rgba(255, 255, 255, 0.45)"
              strokeDasharray="2 3"
              strokeWidth="1.5"
            />
            <circle
              cx="200"
              cy="200"
              r="172"
              stroke="rgba(255, 255, 255, 0.25)"
              strokeWidth="1"
            />

            {/* 0mm to 15mm Metric Scale Along Arc */}
            <g stroke="rgba(255, 255, 255, 0.7)" strokeWidth="1.5">
              <line x1="200" x2="200" y1="15" y2="28" />
              <line x1="230" x2="228" y1="17" y2="25" />
              <line x1="260" x2="255" y1="24" y2="33" />
              <line x1="290" x2="282" y1="36" y2="44" />
              <line x1="318" x2="308" y1="53" y2="60" />
              <line x1="344" x2="333" y1="75" y2="82" />
              <line x1="365" x2="352" y1="102" y2="108" />
              <line x1="380" x2="368" y1="133" y2="137" />
              <line x1="385" x2="375" y1="165" y2="167" />
              <line x1="385" x2="372" y1="200" y2="200" />
            </g>
            <text
              fill="rgba(255,255,255,0.9)"
              fontFamily="Plus Jakarta Sans"
              fontSize="10"
              fontWeight="700"
              x="203"
              y="38"
            >
              0mm
            </text>
            <text
              fill="rgba(255,255,255,0.9)"
              fontFamily="Plus Jakarta Sans"
              fontSize="10"
              fontWeight="700"
              x="320"
              y="94"
            >
              10mm
            </text>
            <text
              fill="rgba(255,255,255,0.9)"
              fontFamily="Plus Jakarta Sans"
              fontSize="10"
              fontWeight="700"
              x="348"
              y="196"
            >
              15mm
            </text>

            {/* Precision Center Crosshairs with Clear Central Target Circle */}
            <circle
              cx="200"
              cy="200"
              r="28"
              stroke="rgba(255, 255, 255, 0.55)"
              strokeDasharray="3 3"
              strokeWidth="1.5"
            />
            <circle cx="200" cy="200" r="6" stroke="#0a6fe8" strokeWidth="2.5" />
            {/* Axis indicators */}
            <line stroke="rgba(255, 255, 255, 0.75)" strokeWidth="1.5" x1="200" x2="200" y1="130" y2="162" />
            <line stroke="rgba(255, 255, 255, 0.75)" strokeWidth="1.5" x1="200" x2="200" y1="238" y2="270" />
            <line stroke="rgba(255, 255, 255, 0.75)" strokeWidth="1.5" x1="130" x2="162" y1="200" y2="200" />
            <line stroke="rgba(255, 255, 255, 0.75)" strokeWidth="1.5" x1="238" x2="270" y1="200" y2="200" />
          </svg>

          {/* Optical Zoom Multiplier Bar */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1 bg-[#2d3134]/90 backdrop-blur-md px-2 py-1 rounded-full shadow-lg">
            {(['10x', '20x', '40x'] as const).map((mag) => (
              <button
                key={mag}
                type="button"
                onClick={() => {
                  setZoomLevel(mag);
                  onUpdateDeviceState({ opticalMagnification: mag });
                }}
                className={`px-2.5 py-1 rounded-full text-[12px] font-bold transition-all active:scale-95 ${
                  zoomLevel === mag
                    ? 'bg-[#0a6fe8] text-white shadow-xs'
                    : 'text-[#eef1f5] hover:text-white'
                }`}
              >
                {mag}
              </button>
            ))}
          </div>

          {/* Dynamic Focal Range & Distance Tag */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 bg-[#2d3134]/90 backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-lg">
            <span className="material-symbols-outlined text-[16px] text-[#10b981]">
              check_circle
            </span>
            <span className="text-[12px] font-semibold text-[#eef1f5] tracking-tight whitespace-nowrap">
              Optimal: In Focus ({focusDistance})
            </span>
          </div>
        </div>
      </div>

      {/* Hardware Physical Trigger Advice Pill */}
      <div className="mx-4 sm:mx-5 mb-2 flex items-center justify-center gap-2 bg-[#f1f4f8] px-4 py-2.5 rounded-full shadow-xs border border-[#e2e8f0]">
        <span
          className="material-symbols-outlined text-[18px] text-[#0a6fe8]"
          style={{ fontVariationSettings: "'FILL' 1" }}
        >
          lightbulb
        </span>
        <span className="text-[13px] text-[#0a2342] text-center font-medium">
          Press the physical button on your scanner handle to capture.
        </span>
      </div>

      {/* Main Viewfinder Controls Strip */}
      <div className="px-4 sm:px-5 mb-2 flex items-center justify-around gap-4">
        {/* LED Intensity Control Capsule */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            aria-label="Adjust LED ring brightness"
            onClick={handleCycleBrightness}
            className="w-14 h-14 rounded-full bg-white text-[#0a2342] flex flex-col items-center justify-center shadow-md active:scale-95 transition-transform border border-[#e2e8f0]"
          >
            <span className="material-symbols-outlined text-[24px] text-amber-500">
              brightness_6
            </span>
            <span className="text-[10px] leading-tight text-[#414754] font-bold">
              {deviceState.isLedOn ? `${deviceState.ringLightBrightness}%` : 'OFF'}
            </span>
          </button>
          <span className="text-[12px] text-[#414754] font-semibold mt-1">Illumination</span>
        </div>

        {/* Oversized Tactile Blue Shutter Ring */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            aria-label="Capture dermatoscopic scan"
            onClick={handleTriggerCapture}
            className="w-20 h-20 rounded-full bg-[#0a6fe8]/15 flex items-center justify-center p-1.5 transition-transform active:scale-90 cursor-pointer"
          >
            <div className="w-full h-full rounded-full bg-[#0a6fe8] text-white flex items-center justify-center shadow-xl shadow-[#0a6fe8]/35 active:bg-[#0057bb] hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[32px]">photo_camera</span>
            </div>
          </button>
          <span className="text-[14px] text-[#0a2342] mt-1 font-bold tracking-tight">Capture</span>
        </div>

        {/* Freeze Frame / Snapshot Preview Tile */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            aria-label="Inspect snapshot preview"
            onClick={() => onNavigate('wound-history')}
            className="w-14 h-14 rounded-xl bg-white overflow-hidden shadow-md flex items-center justify-center relative active:scale-95 transition-transform border border-[#e2e8f0]"
          >
            <img
              className="w-full h-full object-cover"
              alt="Snapshot preview"
              src={ASSETS.recentSnapshot}
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#2d3134]/30 flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px] text-white">history</span>
            </div>
          </button>
          <span className="text-[12px] text-[#414754] font-semibold mt-1">Recent (2)</span>
        </div>
      </div>

      {/* Direct Medical Emergency Escape Link */}
      <div className="px-4 sm:px-5 pt-1 flex justify-center">
        <button
          type="button"
          onClick={onOpenEmergency}
          className="w-full max-w-sm flex items-center justify-center gap-2 bg-[#ffdad6] text-[#93000a] py-3 px-4 rounded-full shadow-xs active:scale-[0.98] transition-transform border border-[#ffb4ac]/40"
        >
          <span
            className="material-symbols-outlined text-[20px] text-[#b21d1e] animate-pulse"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            emergency
          </span>
          <span className="text-[14px] font-bold tracking-tight">
            Severe pain or deep wound? Call 1669
          </span>
        </button>
      </div>
    </div>
  );
};
