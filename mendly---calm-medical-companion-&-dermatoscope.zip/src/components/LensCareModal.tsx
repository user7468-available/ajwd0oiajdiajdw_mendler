import React, { useState } from 'react';

interface LensCareModalProps {
  type: 'cleaning' | 'calibration' | 'help' | null;
  onClose: () => void;
}

export const LensCareModal: React.FC<LensCareModalProps> = ({ type, onClose }) => {
  const [calibrationProgress, setCalibrationProgress] = useState<number>(0);
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);

  if (!type) return null;

  const handleStartCalibration = () => {
    setIsCalibrating(true);
    setCalibrationProgress(15);
    const interval = setInterval(() => {
      setCalibrationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsCalibrating(false);
          return 100;
        }
        return prev + 25;
      });
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#e2e8f0] flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-[#f7fafe] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#c0d5fd]/60 text-[#0a6fe8] flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">
                {type === 'cleaning'
                  ? 'cleaning_services'
                  : type === 'calibration'
                  ? 'straighten'
                  : 'help_outline'}
              </span>
            </div>
            <h3 className="text-[17px] font-bold text-[#0a2342]">
              {type === 'cleaning'
                ? 'Optical Lens Care Procedure'
                : type === 'calibration'
                ? 'Dermoscopic 0.1mm Reticle Calibration'
                : 'Mendly Help & Pairing Guide'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#ebeef2] text-[#0a2342] flex items-center justify-center hover:bg-[#e0e3e7] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {type === 'cleaning' && (
            <div className="space-y-3.5 text-[14px] text-[#0a2342]">
              <p className="leading-relaxed">
                The Mendly dermatoscope uses a sensitive <strong>20x Double Achromat optic</strong>{' '}
                with specialized anti-reflective coating. Follow these laboratory guidelines:
              </p>

              <div className="space-y-2">
                <div className="p-3 bg-[#f1f4f8] rounded-xl flex items-start gap-2.5">
                  <span className="text-[#0a6fe8] font-bold">1.</span>
                  <p className="text-[13px]">
                    Use only the included optical microfiber cloth or medical lens wipes.
                  </p>
                </div>
                <div className="p-3 bg-[#f1f4f8] rounded-xl flex items-start gap-2.5">
                  <span className="text-[#0a6fe8] font-bold">2.</span>
                  <p className="text-[13px]">
                    Dampen slightly with <strong>70% Isopropyl alcohol</strong>. Never submerge the
                    scanner handle in liquid.
                  </p>
                </div>
                <div className="p-3 bg-[#f1f4f8] rounded-xl flex items-start gap-2.5">
                  <span className="text-[#0a6fe8] font-bold">3.</span>
                  <p className="text-[13px]">
                    Wipe gently in spiral circular motions from the center of the lens outward to
                    avoid scratching.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-[#ffdad6]/40 rounded-xl text-[12px] text-[#93000a] border border-[#ffb4ac]/50">
                <strong>Warning:</strong> Never use paper towels, toilet paper, or acetone, as they
                strip the optical polarization film.
              </div>
            </div>
          )}

          {type === 'calibration' && (
            <div className="space-y-4 text-[14px] text-[#0a2342]">
              <p className="leading-relaxed">
                Aligns the 15mm metric circular reticle and autofocus focal plane for micrometer-grade
                wound surface quantification.
              </p>

              <div className="bg-[#f1f4f8] p-4 rounded-2xl flex flex-col items-center justify-center gap-3 border border-[#e2e8f0]">
                <div className="relative w-32 h-32 rounded-full border-2 border-dashed border-[#0a6fe8] flex items-center justify-center bg-white shadow-xs">
                  <span className="material-symbols-outlined text-[36px] text-[#0a6fe8]">
                    center_focus_strong
                  </span>
                  <span className="absolute top-2 text-[10px] font-bold text-[#4a5f81]">0.1mm</span>
                </div>
                <div className="text-center">
                  <span className="text-[13px] font-bold text-[#0a2342] block">
                    {calibrationProgress === 100
                      ? 'Optic Precision Calibrated (0.02mm error)'
                      : isCalibrating
                      ? `Aligning Photodiode Grid... ${calibrationProgress}%`
                      : 'Place scanner over white calibration card'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleStartCalibration}
                disabled={isCalibrating}
                className="w-full py-3 bg-[#0a6fe8] hover:bg-[#0057bb] text-white font-bold text-[14px] rounded-full transition-all active:scale-95 shadow-md cursor-pointer"
              >
                {calibrationProgress === 100
                  ? 'Recalibrate Again'
                  : isCalibrating
                  ? 'Running Calibration...'
                  : 'Start 0.1mm Optical Auto-Calibration'}
              </button>
            </div>
          )}

          {type === 'help' && (
            <div className="space-y-3 text-[14px] text-[#0a2342]">
              <p className="leading-relaxed">
                Troubleshooting tips for your Mendly handheld dermatoscope:
              </p>

              <div className="p-3 bg-[#f1f4f8] rounded-xl space-y-1">
                <h4 className="font-bold text-[13px] text-[#0a2342]">Scanner won’t power on?</h4>
                <p className="text-[12px] text-[#414754]">
                  Connect the USB-C magnetic cable. A solid amber light indicates charging, turning
                  solid green when at 100%.
                </p>
              </div>

              <div className="p-3 bg-[#f1f4f8] rounded-xl space-y-1">
                <h4 className="font-bold text-[13px] text-[#0a2342]">Bluetooth handshake drops?</h4>
                <p className="text-[12px] text-[#414754]">
                  Hold the scanner power button for 5 seconds until the LED pulses blue, then tap
                  "Connect Scanner" on the pairing screen.
                </p>
              </div>

              <div className="p-3 bg-[#f1f4f8] rounded-xl space-y-1">
                <h4 className="font-bold text-[13px] text-[#0a2342]">Blurred images?</h4>
                <p className="text-[12px] text-[#414754]">
                  Maintain a 1.5 cm distance from skin surface until the green "Optimal: In Focus" tag
                  illuminates.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f7fafe] border-t border-[#e2e8f0]">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-[#ebeef2] hover:bg-[#e0e3e7] text-[#0a2342] font-bold text-[14px] rounded-full cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
