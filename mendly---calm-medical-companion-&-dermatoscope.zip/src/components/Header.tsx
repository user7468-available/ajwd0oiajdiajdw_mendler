import React from 'react';
import { ASSETS } from '../data/mockData';
import { ScreenId } from '../types';

interface HeaderProps {
  currentScreen: ScreenId;
  title?: string;
  onBack?: () => void;
  onOpenEmergency: () => void;
  onOpenHelp: () => void;
  onNavigateToDeviceSettings?: () => void;
  isPairingConnected?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  title,
  onBack,
  onOpenEmergency,
  onOpenHelp,
  onNavigateToDeviceSettings,
  isPairingConnected = true,
}) => {
  const isHomeScreen = currentScreen === 'home';

  return (
    <header className="sticky top-0 w-full z-40 pt-safe bg-white/85 backdrop-blur-xl border-b border-[#e2e8f0]/60 shadow-[0_1px_8px_rgba(10,35,66,0.04)]">
      <div className="h-16 px-4 md:px-5 flex items-center justify-between max-w-xl mx-auto">
        {/* Left Slot */}
        {isHomeScreen ? (
          <div className="flex items-center gap-2.5">
            <img
              src={ASSETS.appLogo}
              alt="Mendly App Icon"
              className="h-8 w-auto object-contain"
              referrerPolicy="no-referrer"
            />
            <div className="flex flex-col">
              <span className="font-headline-sm text-[18px] text-[#0a2342] tracking-tight leading-none font-bold">
                Mendly
              </span>
              <span className="text-[12px] text-[#414754] font-normal leading-none mt-0.5">
                AI Companion
              </span>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1">
            <button
              type="button"
              aria-label="Go back"
              onClick={onBack}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[#0a2342] hover:bg-[#ebeef2] active:scale-95 transition-all"
            >
              <span className="material-symbols-outlined text-[24px]">arrow_back</span>
            </button>
            <h1 className="font-headline-sm text-[19px] text-[#0a2342] tracking-tight pl-1 font-bold">
              {title || 'Mendly'}
            </h1>
          </div>
        )}

        {/* Right Slot */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Scanner Connection Sensor Badge (Home only) */}
          {isHomeScreen && (
            <button
              type="button"
              aria-label="Device Scanner Settings"
              onClick={onNavigateToDeviceSettings}
              className="flex items-center justify-center min-w-[40px] min-h-[40px] rounded-full text-[#414754] hover:text-[#0a6fe8] transition-colors"
              title="Scanner connection status"
            >
              <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-[#f1f4f8]">
                <span className="material-symbols-outlined text-[20px] text-[#414754]">sensors</span>
                <span
                  className={`absolute top-1 right-1 w-2 h-2 rounded-full ${
                    isPairingConnected ? 'bg-[#10b981]' : 'bg-[#e0403a]'
                  } animate-pulse`}
                />
              </div>
            </button>
          )}

          {/* Emergency Call Shortcut */}
          <button
            type="button"
            onClick={onOpenEmergency}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#ffdad6] text-[#93000a] min-h-[36px] shadow-xs active:scale-95 transition-transform"
            aria-label="Call emergency 1669"
          >
            <span className="material-symbols-outlined text-[17px] text-[#e0403a]">call</span>
            <span className="text-[12px] font-bold text-[#e0403a] tracking-tight">
              {isHomeScreen ? '911 / 1669' : '1669'}
            </span>
          </button>

          {/* Help Button (non-home or home) */}
          {!isHomeScreen && (
            <button
              type="button"
              onClick={onOpenHelp}
              aria-label="Help and Options"
              className="flex items-center justify-center min-w-[40px] min-h-[40px] rounded-full text-[#414754] hover:text-[#0a2342] active:scale-95 transition-colors"
            >
              <span className="material-symbols-outlined text-[22px]">help_outline</span>
            </button>
          )}

          {/* Profile Avatar */}
          <button
            type="button"
            aria-label="Profile"
            onClick={onOpenHelp}
            className="flex items-center justify-center min-w-[40px] min-h-[40px] p-0.5 rounded-full hover:ring-2 hover:ring-[#0a6fe8]/30 transition-all active:scale-95"
          >
            <img
              alt="Profile Avatar"
              className="w-8 h-8 rounded-full object-cover shadow-xs border border-white"
              src={ASSETS.avatar}
              referrerPolicy="no-referrer"
            />
          </button>
        </div>
      </div>
    </header>
  );
};
