import React from 'react';
import { ASSETS } from '../data/mockData';
import { DeviceState, ProtocolGuide, ScreenId, WoundRecord } from '../types';

interface HomeScreenProps {
  deviceState: DeviceState;
  wounds: WoundRecord[];
  onNavigate: (screen: ScreenId) => void;
  onOpenEmergency: () => void;
  onSelectProtocol: (protocolId: string) => void;
  onUsePhoneCamera: () => void;
  onInspectWound: (wound: WoundRecord) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  deviceState,
  wounds,
  onNavigate,
  onOpenEmergency,
  onSelectProtocol,
  onUsePhoneCamera,
  onInspectWound,
}) => {
  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-28 pt-2 space-y-5">
      {/* Urgent Emergency Alert Banner */}
      <aside
        aria-label="Urgent Assistance Alert"
        className="relative overflow-hidden w-full bg-[#ffdad6]/70 rounded-2xl p-4 shadow-xs border border-[#ffb4ac]/30"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="flex-shrink-0 w-2.5 h-2.5 rounded-full bg-[#e0403a] animate-ping" />
            <div className="flex flex-col min-w-0">
              <p className="font-headline-sm text-[16px] text-[#93000a] font-bold leading-tight truncate">
                Severe bleeding or fainting?
              </p>
              <p className="text-[13px] text-[#93000a]/85 leading-tight mt-0.5">
                Immediate emergency guidance
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenEmergency}
            className="inline-flex items-center justify-center gap-1.5 px-4 h-11 bg-[#d53833] hover:bg-[#b21d1e] text-white font-semibold text-[14px] rounded-full shadow-md active:scale-95 transition-all flex-shrink-0"
          >
            <span
              className="material-symbols-outlined text-[18px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              emergency
            </span>
            <span>SOS 1669</span>
          </button>
        </div>
      </aside>

      {/* Hardware Device Status Card */}
      <section
        aria-label="Connected Hardware Device"
        className="w-full bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.06)] border border-[#e2e8f0]/70 relative overflow-hidden"
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#ebeef2]">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative w-12 h-12 rounded-xl bg-[#f1f4f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-[#e2e8f0]/80">
              <img
                alt="Mendly Scanner Pro"
                className="w-full h-full object-cover"
                src={ASSETS.scannerProThumbnail}
                referrerPolicy="no-referrer"
              />
              <span
                className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                  deviceState.isConnected ? 'bg-[#10b981]' : 'bg-[#e0403a]'
                }`}
              />
            </div>
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-[16px] font-bold text-[#0a2342] truncate">
                  {deviceState.name}
                </h3>
                {deviceState.isConnected ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#e8f8f2] text-[#0b7b56] text-[12px] font-semibold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse" />
                    Active
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => onNavigate('pair-device')}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#fee2e2] text-[#991b1b] text-[12px] font-semibold hover:underline"
                  >
                    Tap to Pair
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2 text-[#414754] text-[13px] mt-0.5">
                <span className="inline-flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px] text-[#0a6fe8]">
                    {deviceState.isConnected ? 'bluetooth_connected' : 'bluetooth_disabled'}
                  </span>
                  {deviceState.isConnected ? 'Sync Ready' : 'Disconnected'}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px] text-[#10b981]">
                    battery_5_bar
                  </span>
                  {deviceState.battery}%
                </span>
              </div>
            </div>
          </div>
          <button
            type="button"
            aria-label="Device Configuration"
            onClick={() => onNavigate('device-settings')}
            className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#f1f4f8] hover:bg-[#ebeef2] text-[#414754] hover:text-[#0a6fe8] active:scale-95 transition-all flex-shrink-0"
            title="Device Settings"
          >
            <span className="material-symbols-outlined text-[20px]">tune</span>
          </button>
        </div>

        {/* Optics Sub-status strip */}
        <div className="mt-3 pt-1 flex items-center justify-between text-[#414754] text-[12px] font-medium">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#0a6fe8]">flare</span>
            <span>
              Ring Light: {deviceState.isLedOn ? `${deviceState.ringLightBrightness}%` : 'Standby'}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#4a5f81]">
              center_focus_strong
            </span>
            <span>{deviceState.opticalMagnification} Micro-Lens Ready</span>
          </div>
        </div>
      </section>

      {/* Reassuring Greeting Card with Friendly First Aid Companion */}
      <section className="w-full bg-gradient-to-br from-[#c0d5fd]/35 via-white to-[#f1f4f8] rounded-2xl p-5 shadow-xs border border-[#c0d5fd]/40 relative overflow-hidden">
        <div className="flex items-center justify-between gap-4">
          <div className="flex flex-col space-y-1.5 max-w-[62%]">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-[#0a6fe8] text-[12px] font-semibold w-fit shadow-xs border border-[#c0d5fd]/40">
              <span className="material-symbols-outlined text-[15px]">self_improvement</span>
              <span>Take a slow, gentle breath</span>
            </div>
            <h2 className="text-[24px] font-bold text-[#0a2342] tracking-tight leading-snug">
              Hurt yourself?
            </h2>
            <p className="text-[14px] text-[#414754] leading-relaxed">
              We are here with you. Scan your skin or wound for immediate care steps.
            </p>
          </div>
          <div className="w-28 h-28 flex-shrink-0 flex items-center justify-center relative">
            <div className="absolute inset-0 rounded-full bg-[#0a6fe8]/10 blur-xl" />
            <img
              alt="Friendly Mendly First Aid Companion"
              className="w-full h-full object-contain relative z-10 drop-shadow-sm transition-transform hover:scale-105"
              src={ASSETS.mascot}
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* Primary Assessment Actions */}
      <section aria-label="Scan Actions" className="flex flex-col space-y-3">
        <h3 className="text-[13px] font-bold text-[#414754] tracking-wider uppercase px-1">
          Triage &amp; Analysis
        </h3>

        {/* Primary Action Button: 60px touch target */}
        <button
          type="button"
          onClick={() => onNavigate('scanner-live-view')}
          className="group relative w-full h-[60px] bg-[#0a6fe8] hover:bg-[#0057bb] active:scale-[0.99] text-white font-bold text-[16px] rounded-full flex items-center justify-center gap-3 shadow-[0_8px_20px_-4px_rgba(10,111,232,0.38)] transition-all cursor-pointer"
        >
          <span className="w-9 h-9 rounded-full bg-white/18 flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px] text-white">lens_blur</span>
          </span>
          <span>Scan with Mendly Scanner</span>
          <span className="material-symbols-outlined text-[20px] transition-transform group-hover:translate-x-1">
            arrow_forward
          </span>
        </button>

        {/* Secondary Camera Fallback */}
        <button
          type="button"
          onClick={onUsePhoneCamera}
          className="w-full h-[52px] bg-[#c0d5fd]/45 hover:bg-[#c0d5fd]/70 text-[#0a2342] font-semibold text-[15px] rounded-full flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer border border-[#c0d5fd]/50"
        >
          <span className="material-symbols-outlined text-[20px] text-[#0a6fe8]">
            photo_camera
          </span>
          <span>No scanner nearby? Use phone camera</span>
        </button>

        {/* Friendly Guidance Footnote */}
        <div className="flex items-center gap-2 px-2 py-1 text-[#414754] text-[13px] justify-center text-center">
          <span className="material-symbols-outlined text-[16px] text-[#0a6fe8] flex-shrink-0">
            lightbulb
          </span>
          <span>Hold scanner tip 1-2 cm above wound. LED ring triggers automatically.</span>
        </div>
      </section>

      {/* Healing Progress & Active Cases */}
      <section aria-label="Active Wound Records" className="flex flex-col space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[19px] font-bold text-[#0a2342]">Recent Scans</h3>
          <button
            type="button"
            onClick={() => onNavigate('wound-history')}
            className="text-[14px] font-semibold text-[#0a6fe8] hover:underline"
          >
            View All
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {wounds.slice(0, 2).map((wound) => (
            <article
              key={wound.id}
              onClick={() => onInspectWound(wound)}
              className="bg-white p-3.5 rounded-2xl shadow-xs border border-[#e2e8f0]/80 flex flex-col justify-between space-y-3 hover:shadow-md hover:border-[#0a6fe8]/40 transition-all cursor-pointer active:scale-[0.99]"
            >
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-xl bg-[#f1f4f8] flex items-center justify-center text-[#0a6fe8]">
                  <span className="material-symbols-outlined text-[18px]">
                    {wound.category.includes('Burn') ? 'local_fire_department' : 'healing'}
                  </span>
                </span>
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[12px] font-bold ${
                    wound.status === 'Healing' || wound.healedPercent > 70
                      ? 'bg-[#e8f8f2] text-[#0b7b56]'
                      : 'bg-[#fef3c7] text-[#b45309]'
                  }`}
                >
                  {wound.healedPercent}% healed
                </span>
              </div>
              <div>
                <p className="text-[15px] text-[#0a2342] font-bold truncate">{wound.title}</p>
                <p className="text-[12px] text-[#414754] mt-0.5">
                  {wound.clinicalNotes.split(',')[0]} • {wound.timestamp}
                </p>
              </div>
              <div className="w-full bg-[#f1f4f8] h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    wound.status === 'Healing' || wound.healedPercent > 70
                      ? 'bg-[#0a6fe8]'
                      : 'bg-[#f59e0b]'
                  }`}
                  style={{ width: `${wound.healedPercent}%` }}
                />
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Quick Care Protocols Shortcuts */}
      <section aria-label="First Aid Protocols" className="flex flex-col space-y-2.5">
        <h3 className="text-[19px] font-bold text-[#0a2342] px-1">Quick Care Protocols</h3>
        <div className="grid grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => onSelectProtocol('first-aid-basics')}
            className="bg-white p-3 rounded-2xl shadow-xs border border-[#e2e8f0]/80 flex flex-col items-center text-center space-y-2 hover:bg-[#f1f4f8] active:scale-95 transition-all"
          >
            <span className="w-11 h-11 rounded-full bg-[#c0d5fd]/45 text-[#0a6fe8] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">medical_services</span>
            </span>
            <span className="text-[13px] text-[#0a2342] font-semibold leading-tight">
              First Aid Basics
            </span>
          </button>

          <button
            type="button"
            onClick={() => onSelectProtocol('bleeding-help')}
            className="bg-white p-3 rounded-2xl shadow-xs border border-[#e2e8f0]/80 flex flex-col items-center text-center space-y-2 hover:bg-[#f1f4f8] active:scale-95 transition-all"
          >
            <span className="w-11 h-11 rounded-full bg-[#ffdad6]/60 text-[#e0403a] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">water_drop</span>
            </span>
            <span className="text-[13px] text-[#0a2342] font-semibold leading-tight">
              Bleeding Help
            </span>
          </button>

          <button
            type="button"
            onClick={() => onSelectProtocol('thermal-burns')}
            className="bg-white p-3 rounded-2xl shadow-xs border border-[#e2e8f0]/80 flex flex-col items-center text-center space-y-2 hover:bg-[#f1f4f8] active:scale-95 transition-all"
          >
            <span className="w-11 h-11 rounded-full bg-[#ffdad6] text-[#b21d1e] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">local_fire_department</span>
            </span>
            <span className="text-[13px] text-[#0a2342] font-semibold leading-tight">
              Thermal Burns
            </span>
          </button>
        </div>
      </section>

      {/* First Aid Kit Readiness Banner */}
      <section
        aria-label="Kit Inventory Status"
        onClick={() => onNavigate('first-aid-guide')}
        className="w-full bg-[#f1f4f8] rounded-2xl p-4 flex items-center justify-between gap-3 border border-[#e2e8f0] cursor-pointer hover:bg-[#ebeef2] active:scale-[0.99] transition-all"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white text-[#0a6fe8] flex items-center justify-center shadow-xs border border-[#e2e8f0]">
            <span className="material-symbols-outlined text-[22px]">inventory_2</span>
          </div>
          <div>
            <p className="text-[15px] text-[#0a2342] font-bold">Home First Aid Kit</p>
            <p className="text-[13px] text-[#414754]">14 of 16 essential items in stock</p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 text-[#0a6fe8] text-[14px] font-bold">
          <span>Check</span>
          <span className="material-symbols-outlined text-[18px]">chevron_right</span>
        </span>
      </section>
    </div>
  );
};
