import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';
import { DeviceState, ScreenId } from '../types';

interface PairDeviceScreenProps {
  deviceState: DeviceState;
  onUpdateDeviceState: (updates: Partial<DeviceState>) => void;
  onNavigate: (screen: ScreenId) => void;
  onOpenHelp: () => void;
}

export const PairDeviceScreen: React.FC<PairDeviceScreenProps> = ({
  deviceState,
  onUpdateDeviceState,
  onNavigate,
  onOpenHelp,
}) => {
  const [pairingState, setPairingState] = useState<'idle' | 'pairing' | 'connected'>(
    deviceState.isConnected ? 'connected' : 'idle'
  );
  const [statusMessage, setStatusMessage] = useState(
    deviceState.isConnected
      ? 'Connected • Ready for Dermascan'
      : 'Searching for nearby Mendly devices...'
  );

  const handleConnect = () => {
    if (pairingState === 'connected') {
      onNavigate('home');
      return;
    }

    setPairingState('pairing');
    setStatusMessage('Authenticating hardware handshake...');

    setTimeout(() => {
      setPairingState('connected');
      setStatusMessage('Connected • Ready for Dermascan');
      onUpdateDeviceState({
        isConnected: true,
        battery: 100,
        signalStrength: '-42 dBm (Strong)',
      });

      // Optionally navigate after short delay or let user proceed
      setTimeout(() => {
        onNavigate('home');
      }, 1400);
    }, 1300);
  };

  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-20 pt-2">
      {/* Header Intro Context */}
      <div className="mt-1 flex flex-col gap-1.5">
        <div className="inline-flex items-center gap-1.5 self-start px-3 py-1 rounded-full bg-[#c0d5fd] text-[#475c7e]">
          <span
            className="material-symbols-outlined text-[16px] text-[#0a6fe8]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            sensors
          </span>
          <span className="text-[12px] font-bold">Bluetooth LE Smart Pairing</span>
        </div>
        <h2 className="text-[26px] font-extrabold text-[#0a2342] mt-1 tracking-tight">
          Pair Your Scanner
        </h2>
        <p className="text-[14px] text-[#414754]">
          Connect your handheld Mendly dermatoscope in just a few seconds.
        </p>
      </div>

      {/* Radar & Device Spotlight Section */}
      <div className="relative w-full my-6 flex flex-col items-center justify-center py-8 rounded-3xl bg-gradient-to-b from-[#f1f4f8] to-[#ebeef2] overflow-hidden shadow-xs border border-[#e2e8f0]">
        {/* Concentric Animated Pulse Waves */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className="absolute w-72 h-72 rounded-full bg-[#0a6fe8]/5 animate-ping"
            style={{ animationDuration: '3s', animationIterationCount: 'infinite' }}
          />
          <div
            className="absolute w-56 h-56 rounded-full bg-[#0a6fe8]/10 animate-pulse"
            style={{ animationDuration: '2s', animationIterationCount: 'infinite' }}
          />
          <div className="absolute w-40 h-40 rounded-full bg-[#d8e2ff]/50" />
        </div>

        {/* Centered Scanner Showcase */}
        <div className="relative z-10 w-44 h-44 rounded-2xl flex items-center justify-center p-2.5 bg-white shadow-md border border-[#e2e8f0]/80">
          <img
            className="w-full h-full object-contain rounded-xl"
            alt="Mendly Dermatoscope Scanner"
            src={ASSETS.scannerTable}
            referrerPolicy="no-referrer"
          />
          {/* Active Wireless Beacon Ping */}
          <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0a6fe8] opacity-75" />
            <span className="relative inline-flex rounded-full h-4 w-4 bg-[#0a6fe8]" />
          </span>
        </div>

        {/* Realtime Pulse Pill */}
        <div className="relative z-10 mt-6 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/95 backdrop-blur-md shadow-xs border border-[#e2e8f0]">
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              pairingState === 'connected' ? 'bg-[#10b981]' : 'bg-[#0a6fe8] animate-pulse'
            }`}
          />
          <span className="text-[12px] text-[#0a2342] font-semibold tracking-wide">
            {statusMessage}
          </span>
        </div>
      </div>

      {/* Found Device Card (Discovered Hardware Tile) */}
      <div
        className={`w-full bg-white rounded-2xl p-4 shadow-xs border border-[#e2e8f0] transition-all duration-300 transform ${
          pairingState === 'connected' ? 'ring-2 ring-[#10b981]/40 scale-[1.01]' : ''
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-12 h-12 rounded-full bg-[#0a6fe8]/10 flex items-center justify-center text-[#0a6fe8] shrink-0 border border-[#0a6fe8]/20">
              <span className="material-symbols-outlined text-[26px]">medical_services</span>
            </div>
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1.5">
                <h3 className="text-[17px] font-bold text-[#0a2342] truncate">
                  {deviceState.name} #4129
                </h3>
                <span
                  className="material-symbols-outlined text-[#0a6fe8] text-[18px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  check_circle
                </span>
              </div>
              <span className="text-[13px] text-[#414754] flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0a6fe8]" />
                Ready to pair • Strong signal (-42 dBm)
              </span>
            </div>
          </div>
          <div className="flex flex-col items-end shrink-0 pl-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#e5e8ec] text-[#0a2342] text-[12px] font-bold">
              <span
                className="material-symbols-outlined text-[15px] text-[#0a6fe8]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                battery_full
              </span>
              100%
            </span>
            <span className="text-[12px] text-[#414754] mt-0.5 font-medium">Charged</span>
          </div>
        </div>
      </div>

      {/* Quick Setup Step Guide Cards */}
      <div className="flex flex-col gap-3 mt-5">
        <p className="text-[13px] font-bold text-[#414754] uppercase tracking-wider pl-1">
          Simple Setup Instructions
        </p>

        {/* Step 1 */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-[#e2e8f0]/80 flex items-start gap-3.5">
          <div className="w-8 h-8 rounded-full bg-[#c0d5fd] text-[#021c3a] flex items-center justify-center shrink-0 text-[14px] font-bold">
            1
          </div>
          <div className="flex flex-col flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-[16px] font-bold text-[#0a2342]">Turn on your scanner</h4>
              <span className="material-symbols-outlined text-[#414754] text-[20px]">
                power_settings_new
              </span>
            </div>
            <p className="text-[13px] text-[#414754] mt-1 leading-relaxed">
              Press and hold the circular power button for 2 seconds until the LED ring flashes soft
              blue.
            </p>
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-[#e2e8f0]/80 flex items-start gap-3.5">
          <div className="w-8 h-8 rounded-full bg-[#c0d5fd] text-[#021c3a] flex items-center justify-center shrink-0 text-[14px] font-bold">
            2
          </div>
          <div className="flex flex-col flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-[16px] font-bold text-[#0a2342]">Hold it near your phone</h4>
              <span className="material-symbols-outlined text-[#414754] text-[20px]">
                stay_current_portrait
              </span>
            </div>
            <p className="text-[13px] text-[#414754] mt-1 leading-relaxed">
              Keep the scanner within 1 meter of your phone with Bluetooth enabled for an immediate
              handshake.
            </p>
          </div>
        </div>
      </div>

      {/* Nurse Reassurance Note */}
      <div className="mt-4 p-3.5 rounded-2xl bg-[#c0d5fd]/40 flex items-center gap-3 border border-[#c0d5fd]/60">
        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#0a6fe8] shrink-0 shadow-xs">
          <span
            className="material-symbols-outlined text-[18px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            verified
          </span>
        </div>
        <p className="text-[13px] text-[#0a2342] leading-snug">
          Once paired, your Mendly scanner will auto-connect effortlessly whenever you pop off the
          protective lens cap.
        </p>
      </div>

      {/* Primary Bottom Actions */}
      <div className="mt-6 flex flex-col gap-2.5">
        <button
          type="button"
          onClick={handleConnect}
          disabled={pairingState === 'pairing'}
          className={`w-full h-14 rounded-full font-bold text-[16px] flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all cursor-pointer ${
            pairingState === 'connected'
              ? 'bg-[#10b981] text-white shadow-[#10b981]/30'
              : pairingState === 'pairing'
              ? 'bg-[#0a6fe8]/80 text-white cursor-wait'
              : 'bg-[#0a6fe8] hover:bg-[#0057bb] text-white shadow-[#0a6fe8]/30'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">
            {pairingState === 'connected'
              ? 'check_circle'
              : pairingState === 'pairing'
              ? 'sync'
              : 'link'}
          </span>
          <span>
            {pairingState === 'connected'
              ? 'Scanner Connected! (Ready)'
              : pairingState === 'pairing'
              ? 'Pairing with Scanner...'
              : 'Connect Scanner'}
          </span>
        </button>

        <div className="flex items-center justify-between px-2 pt-1">
          <button
            type="button"
            onClick={onOpenHelp}
            className="text-[13px] font-bold text-[#0a6fe8] py-2 active:opacity-75 transition-opacity inline-flex items-center gap-1 hover:underline"
          >
            <span className="material-symbols-outlined text-[16px]">help_outline</span>
            <span>Trouble pairing? Help guide</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setStatusMessage('Refreshing Bluetooth broadcast channels...');
              setTimeout(() => {
                setStatusMessage('Mendly Scanner Pro #4129 detected nearby (-42 dBm)');
              }, 800);
            }}
            className="text-[13px] font-semibold text-[#414754] py-2 active:opacity-75 hover:text-[#0a2342] transition-colors"
          >
            Manual Bluetooth search
          </button>
        </div>
      </div>
    </div>
  );
};
