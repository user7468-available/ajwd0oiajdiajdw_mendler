import React, { useState } from 'react';
import { INITIAL_KIT_ITEMS, PROTOCOL_GUIDES } from '../data/mockData';
import { KitItem, ProtocolGuide, ScreenId } from '../types';

interface FirstAidGuideScreenProps {
  initialProtocolId?: string;
  onNavigate: (screen: ScreenId) => void;
  onOpenEmergency: () => void;
}

export const FirstAidGuideScreen: React.FC<FirstAidGuideScreenProps> = ({
  initialProtocolId,
  onNavigate,
  onOpenEmergency,
}) => {
  const [activeTab, setActiveTab] = useState<'protocols' | 'kit'>('protocols');
  const [selectedProtocol, setSelectedProtocol] = useState<string>(
    initialProtocolId || 'first-aid-basics'
  );
  const [kitItems, setKitItems] = useState<KitItem[]>(INITIAL_KIT_ITEMS);

  const toggleKitItem = (id: string) => {
    setKitItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, inStock: !item.inStock } : item))
    );
  };

  const inStockCount = kitItems.filter((i) => i.inStock).length;

  const currentProtocol =
    PROTOCOL_GUIDES.find((p) => p.id === selectedProtocol) || PROTOCOL_GUIDES[0];

  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-24 pt-2 space-y-4">
      {/* Top Segmented Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#ebeef2] rounded-xl">
        <button
          type="button"
          onClick={() => setActiveTab('protocols')}
          className={`flex-1 py-2 rounded-lg text-[14px] font-bold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'protocols'
              ? 'bg-white text-[#0a6fe8] shadow-xs'
              : 'text-[#414754] hover:text-[#0a2342]'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">menu_book</span>
          <span>Care Protocols</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('kit')}
          className={`flex-1 py-2 rounded-lg text-[14px] font-bold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'kit'
              ? 'bg-white text-[#0a6fe8] shadow-xs'
              : 'text-[#414754] hover:text-[#0a2342]'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">inventory_2</span>
          <span>Home First Aid Kit</span>
          <span className="px-1.5 py-0.2 rounded-full bg-[#e8f8f2] text-[#0b7b56] text-[11px] font-bold">
            {inStockCount}/16
          </span>
        </button>
      </div>

      {activeTab === 'protocols' ? (
        <div className="space-y-4">
          {/* Protocol Selector Chips */}
          <div className="grid grid-cols-3 gap-2">
            {PROTOCOL_GUIDES.map((proto) => {
              const isSelected = selectedProtocol === proto.id;
              return (
                <button
                  key={proto.id}
                  type="button"
                  onClick={() => setSelectedProtocol(proto.id)}
                  className={`p-2.5 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white border-[#0a6fe8] ring-2 ring-[#0a6fe8]/20 shadow-xs'
                      : 'bg-white border-[#e2e8f0] text-[#414754] hover:bg-[#f1f4f8]'
                  }`}
                >
                  <span
                    className="w-9 h-9 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: proto.color }}
                  >
                    <span className="material-symbols-outlined text-[20px]">{proto.icon}</span>
                  </span>
                  <span
                    className={`text-[12px] font-bold leading-tight ${
                      isSelected ? 'text-[#0a2342]' : 'text-[#414754]'
                    }`}
                  >
                    {proto.title}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Protocol Card */}
          <div className="bg-white rounded-2xl p-5 shadow-xs border border-[#e2e8f0]/80 space-y-4">
            <div className="flex items-center gap-3">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-white shadow-xs"
                style={{ backgroundColor: currentProtocol.color }}
              >
                <span className="material-symbols-outlined text-[24px]">
                  {currentProtocol.icon}
                </span>
              </div>
              <div>
                <h3 className="text-[18px] font-bold text-[#0a2342]">{currentProtocol.title}</h3>
                <p className="text-[13px] text-[#414754]">{currentProtocol.subtitle}</p>
              </div>
            </div>

            <p className="text-[14px] text-[#0a2342] bg-[#f1f4f8] p-3 rounded-xl border border-[#e2e8f0]/80 leading-relaxed font-medium">
              {currentProtocol.summary}
            </p>

            {/* Steps List */}
            <div className="space-y-3">
              <h4 className="text-[14px] font-bold text-[#414754] uppercase tracking-wider">
                Action Steps
              </h4>
              {currentProtocol.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-[#c0d5fd]/60 text-[#0a6fe8] flex items-center justify-center text-[13px] font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <p className="text-[14px] text-[#0a2342] leading-relaxed flex-1">{step}</p>
                </div>
              ))}
            </div>

            {/* Critical Cautions Box */}
            <div className="bg-[#ffdad6]/40 rounded-xl p-3.5 border border-[#ffb4ac]/50 space-y-1.5">
              <div className="flex items-center gap-1.5 text-[#93000a] font-bold text-[13px]">
                <span className="material-symbols-outlined text-[18px] text-[#e0403a]">warning</span>
                <span>Critical Red Flags &amp; What to Avoid</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[13px] text-[#93000a]">
                {currentProtocol.cautions.map((caution, idx) => (
                  <li key={idx} className="leading-snug">
                    {caution}
                  </li>
                ))}
              </ul>
            </div>

            {/* Quick Emergency Action */}
            <button
              type="button"
              onClick={onOpenEmergency}
              className="w-full py-3 bg-[#ffdad6] text-[#93000a] font-bold text-[14px] rounded-full flex items-center justify-center gap-2 hover:bg-[#ffdad6]/80 transition-colors cursor-pointer border border-[#ffb4ac]/40"
            >
              <span className="material-symbols-outlined text-[18px] text-[#e0403a]">call</span>
              <span>Need Immediate Assistance? 1669 Medical SOS</span>
            </button>
          </div>
        </div>
      ) : (
        /* Home First Aid Kit Inventory Checklist */
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-[#e2e8f0]/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-[#e8f8f2] text-[#0b7b56] flex items-center justify-center">
                <span className="material-symbols-outlined text-[24px]">inventory</span>
              </div>
              <div>
                <h3 className="text-[16px] font-bold text-[#0a2342]">Kit Stock Readiness</h3>
                <p className="text-[13px] text-[#414754]">
                  {inStockCount} of {kitItems.length} essential items stocked
                </p>
              </div>
            </div>
            <span
              className={`text-[13px] font-bold px-3 py-1 rounded-full ${
                inStockCount >= 14
                  ? 'bg-[#e8f8f2] text-[#0b7b56]'
                  : 'bg-[#fef3c7] text-[#b45309]'
              }`}
            >
              {Math.round((inStockCount / kitItems.length) * 100)}% Ready
            </span>
          </div>

          <div className="space-y-2">
            {kitItems.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleKitItem(item.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                  item.inStock
                    ? 'bg-white border-[#e2e8f0]/80 hover:border-[#0a6fe8]/40'
                    : 'bg-[#fff5f5] border-[#fecaca]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                      item.inStock
                        ? 'bg-[#e8f8f2] text-[#0b7b56]'
                        : 'bg-[#fee2e2] text-[#e0403a]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      {item.inStock ? 'check' : 'close'}
                    </span>
                  </div>
                  <div>
                    <p
                      className={`text-[14px] font-bold ${
                        item.inStock ? 'text-[#0a2342]' : 'text-[#991b1b]'
                      }`}
                    >
                      {item.name}
                    </p>
                    <p className="text-[12px] text-[#414754]">
                      {item.category} • In Kit: {item.quantity} (Target: {item.recommended})
                    </p>
                  </div>
                </div>

                <span
                  className={`text-[12px] font-bold px-2.5 py-1 rounded-full ${
                    item.inStock
                      ? 'bg-[#f1f4f8] text-[#414754]'
                      : 'bg-[#fee2e2] text-[#991b1b]'
                  }`}
                >
                  {item.inStock ? 'In Stock' : 'Restock'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
