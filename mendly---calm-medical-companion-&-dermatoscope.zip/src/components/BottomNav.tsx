import React from 'react';
import { ScreenId } from '../types';

interface BottomNavProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  // If in live scanner or result or pair-device, we may conditionally show/hide or keep it clean
  const tabs = [
    {
      id: 'home' as ScreenId,
      label: 'Home',
      icon: 'local_hospital',
    },
    {
      id: 'wound-history' as ScreenId,
      label: 'History',
      icon: 'history',
    },
    {
      id: 'first-aid-guide' as ScreenId,
      label: 'First Aid',
      icon: 'medical_services',
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 pb-safe bg-white/92 backdrop-blur-xl border-t border-[#e2e8f0]/80 shadow-[0_-4px_16px_rgba(10,35,66,0.06)]">
      <div className="h-20 px-4 flex items-center justify-around max-w-xl mx-auto">
        {tabs.map((tab) => {
          const isActive = currentScreen === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onNavigate(tab.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex items-center justify-center gap-2 px-5 min-h-[50px] rounded-full transition-all duration-200 active:scale-95 ${
                isActive
                  ? 'bg-[#c0d5fd] text-[#021c3a] font-bold shadow-xs'
                  : 'text-[#414754] hover:text-[#0a2342] hover:bg-[#f1f4f8]'
              }`}
            >
              <span
                className="material-symbols-outlined text-[23px]"
                style={isActive ? { fontVariationSettings: "'FILL' 1" } : undefined}
              >
                {tab.icon}
              </span>
              <span className="text-[14px] font-semibold">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
