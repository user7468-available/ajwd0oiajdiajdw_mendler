import React, { useEffect, useState } from 'react';
import { ASSETS } from '../data/mockData';
import { ScreenId, WoundRecord } from '../types';

interface ScanResultScreenProps {
  wound?: WoundRecord;
  onScanAgain: () => void;
  onSaveToWounds: (wound: WoundRecord) => void;
  onOpenNurseAi: () => void;
  onOpenEmergency: () => void;
  onNavigate: (screen: ScreenId) => void;
}

export const ScanResultScreen: React.FC<ScanResultScreenProps> = ({
  wound,
  onScanAgain,
  onSaveToWounds,
  onOpenNurseAi,
  onOpenEmergency,
  onNavigate,
}) => {
  // Treatment steps state
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false,
  });

  // Timers state
  const [handwashTimer, setHandwashTimer] = useState<number>(20);
  const [isHandwashRunning, setIsHandwashRunning] = useState<boolean>(false);
  const [handwashCompleted, setHandwashCompleted] = useState<boolean>(false);

  const [holdTimer, setHoldTimer] = useState<number>(180);
  const [isHoldRunning, setIsHoldRunning] = useState<boolean>(false);
  const [holdCompleted, setHoldCompleted] = useState<boolean>(false);

  const [isSaved, setIsSaved] = useState<boolean>(false);

  // Timer 1: Handwash
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isHandwashRunning && handwashTimer > 0) {
      interval = setInterval(() => {
        setHandwashTimer((prev) => {
          if (prev <= 1) {
            setIsHandwashRunning(false);
            setHandwashCompleted(true);
            setCompletedSteps((c) => ({ ...c, 1: true }));
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isHandwashRunning, handwashTimer]);

  // Timer 2: 3-Min Pressure Hold
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isHoldRunning && holdTimer > 0) {
      interval = setInterval(() => {
        setHoldTimer((prev) => {
          if (prev <= 1) {
            setIsHoldRunning(false);
            setHoldCompleted(true);
            setCompletedSteps((c) => ({ ...c, 3: true }));
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isHoldRunning, holdTimer]);

  const toggleStep = (stepNumber: number) => {
    setCompletedSteps((prev) => ({
      ...prev,
      [stepNumber]: !prev[stepNumber],
    }));
  };

  const totalSteps = 4;
  const completedCount = Object.values(completedSteps).filter(Boolean).length;

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleSave = () => {
    setIsSaved(true);
    if (wound) {
      onSaveToWounds(wound);
    }
  };

  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-24 pt-2 space-y-4">
      {/* Status Banner */}
      <div className="w-full bg-[#c0d5fd]/40 rounded-xl p-3 flex items-center justify-between shadow-xs border border-[#c0d5fd]/50">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#0a6fe8] animate-pulse" />
          <div className="flex flex-col">
            <span className="text-[14px] font-bold text-[#0a2342]">
              Scanner Analysis Complete
            </span>
            <span className="text-[12px] text-[#414754]">
              High-Precision 20x Scan • Mendly DermatoAI Core v2.4
            </span>
          </div>
        </div>
        <span
          className="material-symbols-outlined text-[#0a6fe8] text-[22px]"
          style={{ fontVariationSettings: "'FILL' 1" }}
        >
          verified
        </span>
      </div>

      {/* Wound Identification & Metric Card */}
      <div className="w-full bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.06)] border border-[#e2e8f0]/80 flex flex-col gap-3.5">
        {/* Visual & Classification Row */}
        <div className="flex gap-3.5 items-start">
          <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-[#ebeef2] border border-[#e2e8f0]">
            <img
              alt="Close-up dermatoscope view of skin lesion"
              className="w-full h-full object-cover"
              src={wound?.imageUrl || ASSETS.woundDermatoscope}
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-1 right-1 bg-white/90 rounded-full p-1 shadow-xs flex items-center justify-center">
              <span className="material-symbols-outlined text-[#0a6fe8] text-[14px]">lens</span>
            </div>
          </div>
          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="px-2 py-0.5 rounded-full bg-[#c0d5fd]/60 text-[#475c7e] text-[12px] font-bold">
                {wound?.matchScore || 98}% Visual Match
              </span>
              <span className="px-2 py-0.5 rounded-full bg-[#ebeef2] text-[#414754] text-[12px] font-medium">
                {wound?.depthType || 'Epidermal'}
              </span>
            </div>
            <h2 className="text-[19px] font-bold text-[#0a2342] mt-1 leading-snug">
              {wound?.title || 'Shallow Abrasion'}
            </h2>
            <p className="text-[13px] text-[#414754] line-clamp-2 leading-relaxed">
              {wound?.clinicalNotes ||
                'Capillary edges clean, slight peripheral erythema, bleeding controlled.'}
            </p>
          </div>
        </div>

        {/* Scanner Optical Dimension Highlight Box */}
        <div className="bg-[#f1f4f8] rounded-xl p-3 flex flex-col gap-2 border border-[#e2e8f0]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[#0a6fe8]">
              <span className="material-symbols-outlined text-[18px]">straighten</span>
              <span className="text-[14px] font-bold text-[#0a6fe8]">Hardware Measurement</span>
            </div>
            <span className="text-[12px] text-[#414754] font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#0a6fe8]" />
              Calibrated Optic
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-0.5">
            <div className="bg-white rounded-lg p-2.5 shadow-xs border border-[#e2e8f0]/80">
              <span className="text-[12px] text-[#414754] block">Wound Size (L × W)</span>
              <span className="text-[18px] text-[#0a2342] font-extrabold tracking-tight">
                {wound?.dimensions || '14 × 6'}{' '}
                <span className="text-[14px] font-normal text-[#414754]">mm</span>
              </span>
            </div>
            <div className="bg-white rounded-lg p-2.5 shadow-xs border border-[#e2e8f0]/80">
              <span className="text-[12px] text-[#414754] block">Area &amp; Depth</span>
              <span className="text-[18px] text-[#0a2342] font-extrabold tracking-tight">
                {wound?.area || '~84'}{' '}
                <span className="text-[14px] font-normal text-[#414754]">mm²</span>
              </span>
              <span className="text-[11px] text-[#414754] block mt-0.5">
                {wound?.depth || '<0.5 mm depth'}
              </span>
            </div>
          </div>
        </div>

        {/* Triage Severity Status Indicator */}
        <div className="flex flex-col gap-1.5 pt-1">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
              <span className="text-[14px] font-bold text-[#0a2342]">
                {wound?.severityLabel || 'Minor Wound — Safe to treat at home'}
              </span>
            </div>
            <span className="text-[12px] font-semibold text-[#414754]">
              {wound?.severityTier || 'Tier 1/3'}
            </span>
          </div>

          {/* 3-Tier Multi-Segment Bar */}
          <div className="w-full grid grid-cols-3 gap-1.5 h-2 rounded-full overflow-hidden">
            <div className="h-full bg-[#10b981] rounded-full" />
            <div className="h-full bg-[#e0e3e7] rounded-full" />
            <div className="h-full bg-[#e0e3e7] rounded-full" />
          </div>
        </div>
      </div>

      {/* Medical Reassurance & Disclaimer Banner */}
      <div className="w-full bg-[#f1f4f8] rounded-xl p-3.5 flex items-start gap-3 shadow-xs border border-[#e2e8f0]">
        <span
          className="material-symbols-outlined text-[#0a6fe8] text-[22px] shrink-0 mt-0.5"
          style={{ fontVariationSettings: "'FILL' 1" }}
        >
          verified_user
        </span>
        <p className="text-[13px] text-[#414754] leading-relaxed">
          This guidance does not replace a doctor. If bleeding won't stop after 10 minutes or pain
          worsens, seek professional medical care immediately.
        </p>
      </div>

      {/* Immediate First-Aid Steps */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between px-0.5">
          <h3 className="text-[19px] font-bold text-[#0a2342]">Immediate Treatment</h3>
          <span
            className={`text-[13px] font-bold px-3 py-1 rounded-full transition-colors ${
              completedCount === totalSteps
                ? 'bg-[#10b981]/20 text-[#0b7b56]'
                : 'bg-[#d8e2ff]/50 text-[#0a6fe8]'
            }`}
          >
            {completedCount} of {totalSteps} Completed
          </span>
        </div>

        {/* Step 1: Hand Hygiene */}
        <div
          className={`rounded-2xl p-4 shadow-xs border transition-all duration-200 flex flex-col gap-3 ${
            completedSteps[1]
              ? 'bg-[#f1f4f8] border-[#c0d5fd]'
              : 'bg-white border-[#e2e8f0]/80'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-[15px] font-bold shrink-0 ${
                  completedSteps[1]
                    ? 'bg-[#10b981] text-white'
                    : 'bg-[#c0d5fd]/60 text-[#0a6fe8]'
                }`}
              >
                1
              </div>
              <div className="flex flex-col">
                <span className="text-[16px] font-bold text-[#0a2342]">
                  Clean your hands thoroughly
                </span>
                <span className="text-[13px] text-[#414754] mt-0.5 leading-relaxed">
                  Wash hands with warm water and soap for at least 20 seconds before touching the
                  abrasion to prevent infection.
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleStep(1)}
              className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl transition-all cursor-pointer ${
                completedSteps[1]
                  ? 'bg-[#0a6fe8] text-white shadow-xs'
                  : 'bg-[#ebeef2] text-[#414754] hover:bg-[#e0e3e7]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">check</span>
            </button>
          </div>

          {/* Micro Timer Component for Handwashing */}
          <div className="bg-[#f1f4f8] rounded-xl p-3 flex items-center justify-between border border-[#e2e8f0]/70">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#0a6fe8] text-[20px]">
                water_drop
              </span>
              <span className="text-[14px] text-[#0a2342] font-semibold">Handwash Timer</span>
            </div>
            <div className="flex items-center gap-2.5">
              <span className="text-[17px] text-[#0a2342] font-mono font-bold">
                {handwashCompleted ? 'Done!' : `${handwashTimer}s`}
              </span>
              {!handwashCompleted ? (
                <button
                  type="button"
                  onClick={() => setIsHandwashRunning(!isHandwashRunning)}
                  className="px-3.5 py-1.5 bg-[#0a6fe8] hover:bg-[#0057bb] text-white rounded-full text-[12px] font-bold active:scale-95 transition-all shadow-xs cursor-pointer"
                >
                  {isHandwashRunning ? 'Pause' : handwashTimer < 20 ? 'Resume' : 'Start'}
                </button>
              ) : (
                <span className="px-3 py-1 bg-[#10b981] text-white rounded-full text-[12px] font-bold inline-flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px]">done</span> Clean
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Step 2: Lukewarm Water Rinse */}
        <div
          className={`rounded-2xl p-4 shadow-xs border transition-all duration-200 flex flex-col gap-3 ${
            completedSteps[2]
              ? 'bg-[#f1f4f8] border-[#c0d5fd]'
              : 'bg-white border-[#e2e8f0]/80'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-[15px] font-bold shrink-0 ${
                  completedSteps[2]
                    ? 'bg-[#10b981] text-white'
                    : 'bg-[#c0d5fd]/60 text-[#0a6fe8]'
                }`}
              >
                2
              </div>
              <div className="flex flex-col">
                <span className="text-[16px] font-bold text-[#0a2342]">Rinse the cut gently</span>
                <span className="text-[13px] text-[#414754] mt-0.5 leading-relaxed">
                  Hold under gentle, lukewarm tap water to dislodge particulate debris. Avoid harsh
                  alcohol, iodine, or hydrogen peroxide on fresh tissue.
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleStep(2)}
              className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl transition-all cursor-pointer ${
                completedSteps[2]
                  ? 'bg-[#0a6fe8] text-white shadow-xs'
                  : 'bg-[#ebeef2] text-[#414754] hover:bg-[#e0e3e7]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">check</span>
            </button>
          </div>
        </div>

        {/* Step 3: Gentle Pressure */}
        <div
          className={`rounded-2xl p-4 shadow-xs border transition-all duration-200 flex flex-col gap-3 ${
            completedSteps[3]
              ? 'bg-[#f1f4f8] border-[#c0d5fd]'
              : 'bg-white border-[#e2e8f0]/80'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-[15px] font-bold shrink-0 ${
                  completedSteps[3]
                    ? 'bg-[#10b981] text-white'
                    : 'bg-[#c0d5fd]/60 text-[#0a6fe8]'
                }`}
              >
                3
              </div>
              <div className="flex flex-col">
                <span className="text-[16px] font-bold text-[#0a2342]">
                  Apply gentle steady pressure
                </span>
                <span className="text-[13px] text-[#414754] mt-0.5 leading-relaxed">
                  Hold a clean gauze or lint-free pad over the cut for 3 continuous minutes until
                  capillary ooze fully coagulates.
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleStep(3)}
              className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl transition-all cursor-pointer ${
                completedSteps[3]
                  ? 'bg-[#0a6fe8] text-white shadow-xs'
                  : 'bg-[#ebeef2] text-[#414754] hover:bg-[#e0e3e7]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">check</span>
            </button>
          </div>

          {/* Coagulation Timer */}
          <div className="bg-[#f1f4f8] rounded-xl p-3 flex items-center justify-between border border-[#e2e8f0]/70">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#0a6fe8] text-[20px]">timer</span>
              <span className="text-[14px] text-[#0a2342] font-semibold">3-Min Hold Timer</span>
            </div>
            <div className="flex items-center gap-2.5">
              <span className="text-[17px] text-[#0a2342] font-mono font-bold">
                {holdCompleted ? '00:00 (Done)' : formatTime(holdTimer)}
              </span>
              {!holdCompleted ? (
                <button
                  type="button"
                  onClick={() => setIsHoldRunning(!isHoldRunning)}
                  className="px-3.5 py-1.5 bg-[#0a6fe8] hover:bg-[#0057bb] text-white rounded-full text-[12px] font-bold active:scale-95 transition-all shadow-xs cursor-pointer"
                >
                  {isHoldRunning ? 'Pause' : holdTimer < 180 ? 'Resume' : 'Start'}
                </button>
              ) : (
                <span className="px-3 py-1 bg-[#10b981] text-white rounded-full text-[12px] font-bold inline-flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px]">done</span> Coagulated
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Step 4: Protect with Sterile Bandage */}
        <div
          className={`rounded-2xl p-4 shadow-xs border transition-all duration-200 flex flex-col gap-3 ${
            completedSteps[4]
              ? 'bg-[#f1f4f8] border-[#c0d5fd]'
              : 'bg-white border-[#e2e8f0]/80'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-[15px] font-bold shrink-0 ${
                  completedSteps[4]
                    ? 'bg-[#10b981] text-white'
                    : 'bg-[#c0d5fd]/60 text-[#0a6fe8]'
                }`}
              >
                4
              </div>
              <div className="flex flex-col">
                <span className="text-[16px] font-bold text-[#0a2342]">
                  Protect with a breathable dressing
                </span>
                <span className="text-[13px] text-[#414754] mt-0.5 leading-relaxed">
                  Apply a thin dab of petroleum jelly and seal with a sterile fingertip adhesive
                  strip. Replace daily or whenever wet.
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleStep(4)}
              className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl transition-all cursor-pointer ${
                completedSteps[4]
                  ? 'bg-[#0a6fe8] text-white shadow-xs'
                  : 'bg-[#ebeef2] text-[#414754] hover:bg-[#e0e3e7]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">check</span>
            </button>
          </div>
        </div>
      </div>

      {/* Reassurance Human Warmth Card */}
      <div className="w-full bg-[#f1f4f8]/85 rounded-2xl p-4 flex items-center gap-3.5 shadow-xs border border-[#e2e8f0]">
        <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0 shadow-xs border border-[#e2e8f0]">
          <span
            className="material-symbols-outlined text-[#0a6fe8] text-[22px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            favorite
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-[14px] font-bold text-[#0a2342]">You're doing great!</span>
          <span className="text-[13px] text-[#414754] leading-relaxed">
            Small cuts of this size typically seal and heal cleanly within 3 to 7 days.
          </span>
        </div>
      </div>

      {/* Action CTAs */}
      <div className="flex flex-col gap-2.5 pt-1">
        {/* Primary CTA */}
        <button
          type="button"
          onClick={handleSave}
          className={`w-full h-14 rounded-full font-bold text-[16px] flex items-center justify-center gap-2 shadow-md active:scale-[0.99] transition-all cursor-pointer ${
            isSaved
              ? 'bg-[#10b981] text-white'
              : 'bg-[#0a6fe8] hover:bg-[#0057bb] text-white shadow-[#0a6fe8]/30'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">
            {isSaved ? 'check_circle' : 'bookmark_add'}
          </span>
          <span>{isSaved ? 'Saved to My Wounds!' : 'Save to My Wounds'}</span>
        </button>

        {/* Secondary Row */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onScanAgain}
            className="h-12 bg-[#c0d5fd]/50 hover:bg-[#c0d5fd]/75 text-[#0a2342] rounded-full font-semibold text-[14px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer border border-[#c0d5fd]/60"
          >
            <span className="material-symbols-outlined text-[18px]">cached</span>
            <span>Scan Again</span>
          </button>
          <button
            type="button"
            onClick={onOpenNurseAi}
            className="h-12 bg-[#c0d5fd]/50 hover:bg-[#c0d5fd]/75 text-[#0a2342] rounded-full font-semibold text-[14px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer border border-[#c0d5fd]/60"
          >
            <span className="material-symbols-outlined text-[18px] text-[#0a6fe8]">
              support_agent
            </span>
            <span>Ask Nurse AI</span>
          </button>
        </div>

        {/* Emergency Fallback Link */}
        <div className="text-center pt-2">
          <button
            type="button"
            onClick={onOpenEmergency}
            className="inline-flex items-center gap-1 text-[#414754] hover:text-[#e0403a] transition-colors text-[13px] font-medium"
          >
            <span className="material-symbols-outlined text-[16px] text-[#e0403a]">warning</span>
            <span>
              Not feeling right?{' '}
              <strong className="text-[#e0403a] font-bold underline">
                View Emergency Steps (1669)
              </strong>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
