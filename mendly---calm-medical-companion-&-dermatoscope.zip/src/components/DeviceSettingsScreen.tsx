import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';
import { DeviceState, ScreenId } from '../types';

interface DeviceSettingsScreenProps {
  deviceState: DeviceState;
  onUpdateDeviceState: (updates: Partial<DeviceState>) => void;
  onOpenLensCare: () => void;
  onOpenCalibration: () => void;
  onNavigate: (screen: ScreenId) => void;
}

export const DeviceSettingsScreen: React.FC<DeviceSettingsScreenProps> = ({
  deviceState,
  onUpdateDeviceState,
  onOpenLensCare,
  onOpenCalibration,
  onNavigate,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [scannerName, setScannerName] = useState(deviceState.name);
  const [disconnecting, setDisconnecting] = useState(false);
  const [showTimeoutDropdown, setShowTimeoutDropdown] = useState(false);
  const [showButtonModal, setShowButtonModal] = useState<'single' | 'double' | null>(null);

  const handleSaveName = () => {
    if (scannerName.trim()) {
      onUpdateDeviceState({ name: scannerName.trim() });
    }
    setIsEditingName(false);
  };

  const handleSetLight = (level: 30 | 65 | 100) => {
    onUpdateDeviceState({
      ringLightBrightness: level,
      isLedOn: true,
    });
  };

  const handleDisconnect = () => {
    setDisconnecting(true);
    setTimeout(() => {
      const nextState = !deviceState.isConnected;
      onUpdateDeviceState({ isConnected: nextState });
      setDisconnecting(false);
    }, 800);
  };

  const handleForgetDevice = () => {
    if (confirm('Are you sure you want to forget Mendly Scanner Pro? You will need to pair it again.')) {
      onUpdateDeviceState({ isConnected: false });
      onNavigate('pair-device');
    }
  };

  return (
    <div className="flex flex-col w-full max-w-xl mx-auto px-4 sm:px-5 pb-20 pt-2 space-y-4">
      {/* Connected Device Hero Card */}
      <div className="relative overflow-hidden bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 mt-1">
        <div className="flex items-center gap-4">
          {/* Device Product Imagery */}
          <div className="relative w-24 h-24 rounded-xl bg-[#f1f4f8] flex-shrink-0 overflow-hidden flex items-center justify-center p-2 border border-[#e2e8f0]">
            <img
              alt="Mendly Scanner Pro"
              className="w-full h-full object-contain drop-shadow-xs"
              src={ASSETS.scannerProThumbnail}
              referrerPolicy="no-referrer"
            />
            {deviceState.isConnected && (
              <span className="absolute bottom-1 right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0a6fe8] opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#0a6fe8]" />
              </span>
            )}
          </div>

          {/* Device Identity Details */}
          <div className="flex flex-col flex-1 min-w-0">
            <div className="flex items-center justify-between gap-1">
              {isEditingName ? (
                <div className="flex items-center gap-1.5 w-full">
                  <input
                    type="text"
                    value={scannerName}
                    onChange={(e) => setScannerName(e.target.value)}
                    className="text-[16px] font-bold text-[#0a2342] bg-[#f1f4f8] px-2 py-1 rounded-md border border-[#0a6fe8] w-full outline-none"
                    autoFocus
                    onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
                  />
                  <button
                    type="button"
                    onClick={handleSaveName}
                    className="p-1 text-[#0a6fe8] hover:bg-[#c0d5fd]/40 rounded-full"
                  >
                    <span className="material-symbols-outlined text-[18px]">done</span>
                  </button>
                </div>
              ) : (
                <>
                  <h2 className="text-[18px] font-bold text-[#0a2342] truncate">
                    {deviceState.name}
                  </h2>
                  <button
                    type="button"
                    aria-label="Edit device name"
                    onClick={() => setIsEditingName(true)}
                    className="w-8 h-8 flex items-center justify-center rounded-full text-[#4a5f81] hover:text-[#0a6fe8] hover:bg-[#f1f4f8] active:scale-95 transition-all flex-shrink-0"
                  >
                    <span className="material-symbols-outlined text-[18px]">edit</span>
                  </button>
                </>
              )}
            </div>

            <div className="flex items-center gap-1.5 mt-0.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  deviceState.isConnected ? 'bg-[#10b981] animate-pulse' : 'bg-[#727785]'
                }`}
              />
              <span
                className={`text-[12px] font-bold ${
                  deviceState.isConnected ? 'text-[#0b7b56]' : 'text-[#727785]'
                }`}
              >
                {deviceState.isConnected ? 'Connected via BLE 5.2' : 'Disconnected'}
              </span>
            </div>
            <p className="text-[12px] text-[#414754] mt-1 font-mono tracking-tight text-opacity-80">
              {deviceState.serialNumber}
            </p>
          </div>
        </div>
      </div>

      {/* Hardware Vital Diagnostics (Battery & State) */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#e8f8f2] flex items-center justify-center text-[#0b7b56]">
              <span
                className="material-symbols-outlined text-[20px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                battery_charging_90
              </span>
            </div>
            <div>
              <span className="text-[16px] font-bold text-[#0a2342] block">
                {deviceState.battery}% Battery Remaining
              </span>
              <span className="text-[12px] text-[#414754]">~4.2 hrs active scanning left</span>
            </div>
          </div>
          <span className="text-[12px] px-2.5 py-0.5 rounded-full bg-[#e8f8f2] text-[#0b7b56] font-bold">
            Healthy
          </span>
        </div>
        {/* Progress bar track */}
        <div className="w-full bg-[#ebeef2] rounded-full h-2 overflow-hidden">
          <div
            className="bg-[#10b981] h-full rounded-full transition-all duration-500"
            style={{ width: `${deviceState.battery}%` }}
          />
        </div>
      </div>

      {/* Optical Sensor & Illumination Module */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 space-y-4">
        <div className="flex items-center justify-between pb-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#c0d5fd]/50 flex items-center justify-center text-[#0a6fe8]">
              <span className="material-symbols-outlined text-[20px]">lens_blur</span>
            </div>
            <div>
              <span className="text-[16px] font-bold text-[#0a2342] block">Optical Dermatoscope</span>
              <span className="text-[13px] text-[#414754]">20x Ultra-HD Double Achromat</span>
            </div>
          </div>
        </div>

        {/* Ring Light Intensity Customizer */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[14px] font-bold text-[#0a2342] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#4a5f81]">flare</span>
              Polarized Ring Light
            </label>
            <span className="text-[13px] text-[#0a6fe8] font-bold">
              {deviceState.ringLightBrightness}% Brightness
            </span>
          </div>

          {/* Segmented Pill Selector for Quick Field Adjustments */}
          <div className="grid grid-cols-3 gap-2 p-1.5 bg-[#ebeef2] rounded-xl">
            {[
              { level: 30 as const, label: 'Soft (30%)' },
              { level: 65 as const, label: 'Med (65%)' },
              { level: 100 as const, label: 'High (100%)' },
            ].map(({ level, label }) => {
              const isSelected = deviceState.ringLightBrightness === level;
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => handleSetLight(level)}
                  className={`py-2 rounded-lg text-[13px] font-bold transition-all active:scale-95 text-center cursor-pointer ${
                    isSelected
                      ? 'bg-white text-[#0a6fe8] shadow-xs'
                      : 'text-[#414754] hover:text-[#0a2342]'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Auto-Power Sleep Setting */}
        <div className="flex items-center justify-between pt-1 relative">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[20px] text-[#4a5f81]">timer</span>
            <div>
              <p className="text-[14px] font-bold text-[#0a2342]">Auto-Sleep Timeout</p>
              <p className="text-[12px] text-[#414754]">Conserves battery when idling</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowTimeoutDropdown(!showTimeoutDropdown)}
            className="bg-[#ebeef2] hover:bg-[#e0e3e7] px-3.5 py-1.5 rounded-full flex items-center gap-1 cursor-pointer active:scale-95 transition-all text-[#0a2342]"
          >
            <span className="text-[13px] font-semibold">{deviceState.autoSleepMinutes} mins</span>
            <span className="material-symbols-outlined text-[16px] text-[#4a5f81]">
              expand_more
            </span>
          </button>

          {showTimeoutDropdown && (
            <div className="absolute right-0 top-12 z-30 bg-white rounded-xl shadow-lg border border-[#e2e8f0] p-1 w-32 space-y-1">
              {[1, 3, 5, 10].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => {
                    onUpdateDeviceState({ autoSleepMinutes: mins });
                    setShowTimeoutDropdown(false);
                  }}
                  className={`w-full text-left px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${
                    deviceState.autoSleepMinutes === mins
                      ? 'bg-[#c0d5fd]/50 text-[#0a6fe8] font-bold'
                      : 'text-[#0a2342] hover:bg-[#f1f4f8]'
                  }`}
                >
                  {mins} mins
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Hardware Trigger & Tactile Controls */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 space-y-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-full bg-[#d5e3ff] flex items-center justify-center text-[#021c3a]">
            <span className="material-symbols-outlined text-[20px]">touch_app</span>
          </div>
          <div>
            <h3 className="text-[16px] font-bold text-[#0a2342]">Scanner Button Customization</h3>
            <p className="text-[12px] text-[#414754]">Ergonomic side-button actions</p>
          </div>
        </div>

        <div className="space-y-2 pt-1">
          <div
            onClick={() => setShowButtonModal('single')}
            className="p-3 bg-[#f1f4f8] hover:bg-[#ebeef2] rounded-xl flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all border border-[#e2e8f0]/70"
          >
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-[#ebeef2] flex items-center justify-center text-[12px] font-bold text-[#4a5f81]">
                1x
              </span>
              <span className="text-[14px] text-[#0a2342] font-semibold">Single Press</span>
            </div>
            <span className="text-[13px] text-[#0a6fe8] font-bold flex items-center gap-0.5">
              {deviceState.singlePressAction}
              <span className="material-symbols-outlined text-[16px]">chevron_right</span>
            </span>
          </div>

          <div
            onClick={() => setShowButtonModal('double')}
            className="p-3 bg-[#f1f4f8] hover:bg-[#ebeef2] rounded-xl flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all border border-[#e2e8f0]/70"
          >
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-[#ebeef2] flex items-center justify-center text-[12px] font-bold text-[#4a5f81]">
                2x
              </span>
              <span className="text-[14px] text-[#0a2342] font-semibold">Double Press</span>
            </div>
            <span className="text-[13px] text-[#0a6fe8] font-bold flex items-center gap-0.5">
              {deviceState.doublePressAction}
              <span className="material-symbols-outlined text-[16px]">chevron_right</span>
            </span>
          </div>
        </div>
      </div>

      {/* Firmware Health & Diagnostic Suite */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#ebeef2] flex items-center justify-center text-[#4a5f81]">
              <span className="material-symbols-outlined text-[20px]">system_update_alt</span>
            </div>
            <div>
              <span className="text-[15px] font-bold text-[#0a2342] block">Firmware Version</span>
              <span className="text-[13px] text-[#414754] font-mono">{deviceState.firmware}</span>
            </div>
          </div>
          <span className="px-3 py-1.5 rounded-full bg-[#ebeef2] text-[#0b7b56] text-[12px] font-bold flex items-center gap-1">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            Up to date
          </span>
        </div>
      </div>

      {/* Device Care & Optical Maintenance Guides */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_4px_16px_-2px_rgba(10,35,66,0.05)] border border-[#e2e8f0]/80 space-y-2">
        <h3 className="text-[16px] font-bold text-[#0a2342] mb-1">Device Care &amp; Calibration</h3>

        <button
          type="button"
          onClick={onOpenLensCare}
          className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[#f1f4f8] transition-colors active:scale-[0.99] text-left border border-transparent hover:border-[#e2e8f0]"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#ebeef2] flex items-center justify-center text-[#4a5f81]">
              <span className="material-symbols-outlined text-[18px]">cleaning_services</span>
            </div>
            <div>
              <span className="text-[14px] font-bold text-[#0a2342] block">
                How to clean the optical lens
              </span>
              <span className="text-[12px] text-[#414754]">Recommended microfiber procedure</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[20px] text-[#727785]">chevron_right</span>
        </button>

        <button
          type="button"
          onClick={onOpenCalibration}
          className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[#f1f4f8] transition-colors active:scale-[0.99] text-left border border-transparent hover:border-[#e2e8f0]"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#ebeef2] flex items-center justify-center text-[#4a5f81]">
              <span className="material-symbols-outlined text-[18px]">straighten</span>
            </div>
            <div>
              <span className="text-[14px] font-bold text-[#0a2342] block">
                Re-calibrate scale (0.1mm)
              </span>
              <span className="text-[12px] text-[#414754]">Align dermoscopic reticle target</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[20px] text-[#727785]">chevron_right</span>
        </button>
      </div>

      {/* Disconnect & Unpair Actions */}
      <div className="pt-2 space-y-3 flex flex-col items-center">
        <button
          type="button"
          onClick={handleDisconnect}
          disabled={disconnecting}
          className="w-full h-14 rounded-full bg-[#e5e8ec] hover:bg-[#d7dade] text-[#0a6fe8] font-bold text-[16px] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-xs cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">
            {disconnecting ? 'sync' : deviceState.isConnected ? 'link_off' : 'link'}
          </span>
          <span>
            {disconnecting
              ? 'Processing...'
              : deviceState.isConnected
              ? 'Disconnect Scanner'
              : 'Reconnect Scanner'}
          </span>
        </button>

        <button
          type="button"
          onClick={handleForgetDevice}
          className="text-[14px] font-bold text-[#b21d1e] hover:underline py-1 active:opacity-75 cursor-pointer"
        >
          Forget this device
        </button>

        {/* Support Reassurance Badge */}
        <div className="w-full rounded-2xl bg-[#f1f4f8] p-4 text-center flex items-center justify-center gap-2 text-[#414754] mt-2 border border-[#e2e8f0]">
          <span className="material-symbols-outlined text-[20px] text-[#0a6fe8]">support_agent</span>
          <p className="text-[13px]">
            Need a replacement cap or accessories?{' '}
            <a href="#care" className="text-[#0a6fe8] font-bold hover:underline">
              Contact Mendly Care
            </a>
          </p>
        </div>
      </div>

      {/* Button Configuration Modal */}
      {showButtonModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-3 shadow-xl">
            <h3 className="text-[17px] font-bold text-[#0a2342]">
              Customize {showButtonModal === 'single' ? 'Single Press' : 'Double Press'}
            </h3>
            <p className="text-[13px] text-[#414754]">
              Choose the hardware action triggered when pressing the side button:
            </p>
            <div className="space-y-1.5">
              {['Capture Photo', 'Toggle Ring Light', 'Cycle 10x/20x/40x Zoom', 'Start 3-Min Timer'].map(
                (act) => (
                  <button
                    key={act}
                    type="button"
                    onClick={() => {
                      if (showButtonModal === 'single') {
                        onUpdateDeviceState({ singlePressAction: act });
                      } else {
                        onUpdateDeviceState({ doublePressAction: act });
                      }
                      setShowButtonModal(null);
                    }}
                    className="w-full text-left p-3 rounded-xl hover:bg-[#f1f4f8] text-[14px] font-semibold text-[#0a2342] flex items-center justify-between"
                  >
                    <span>{act}</span>
                    <span className="material-symbols-outlined text-[18px] text-[#0a6fe8]">check</span>
                  </button>
                )
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowButtonModal(null)}
              className="w-full py-2.5 rounded-full bg-[#f1f4f8] text-[#0a2342] text-[14px] font-bold"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
