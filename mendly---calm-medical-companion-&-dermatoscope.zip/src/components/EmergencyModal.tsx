import React, { useEffect, useState } from 'react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose }) => {
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setBreathPhase((prev) => {
        if (prev === 'Inhale') return 'Hold';
        if (prev === 'Hold') return 'Exhale';
        return 'Inhale';
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border-2 border-[#e0403a] flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-[#ba1a1a] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span
              className="material-symbols-outlined text-[28px] animate-pulse"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              emergency
            </span>
            <div>
              <h2 className="text-[20px] font-extrabold leading-tight">Emergency Medical Triage</h2>
              <p className="text-[12px] text-white/80">Immediate Life-Safety Protocols</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Main 1-tap Call Actions */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href="tel:1669"
              className="flex flex-col items-center justify-center py-4 px-3 bg-[#e0403a] hover:bg-[#ba1a1a] text-white rounded-2xl shadow-lg shadow-[#e0403a]/25 active:scale-95 transition-all text-center"
            >
              <span className="material-symbols-outlined text-[28px] mb-1">call</span>
              <span className="text-[18px] font-extrabold">1669</span>
              <span className="text-[11px] text-white/80 mt-0.5">Thailand EMS</span>
            </a>

            <a
              href="tel:911"
              className="flex flex-col items-center justify-center py-4 px-3 bg-[#0a2342] hover:bg-[#181c1f] text-white rounded-2xl shadow-lg active:scale-95 transition-all text-center"
            >
              <span className="material-symbols-outlined text-[28px] mb-1">local_police</span>
              <span className="text-[18px] font-extrabold">911 / 191</span>
              <span className="text-[11px] text-white/80 mt-0.5">Universal Police/EMS</span>
            </a>
          </div>

          {/* Calming Breath Stabilizer */}
          <div className="bg-[#f1f4f8] rounded-2xl p-4 flex items-center justify-between border border-[#e2e8f0]">
            <div>
              <span className="text-[11px] font-bold text-[#0a6fe8] uppercase tracking-wider block">
                Shock &amp; Panic Defense
              </span>
              <span className="text-[16px] font-bold text-[#0a2342]">
                {breathPhase === 'Inhale'
                  ? 'Breathe In Slowly...'
                  : breathPhase === 'Hold'
                  ? 'Gently Hold...'
                  : 'Slowly Exhale...'}
              </span>
              <p className="text-[12px] text-[#414754] mt-0.5">
                Lowers adrenaline and stabilizes blood pressure.
              </p>
            </div>
            <div className="w-14 h-14 rounded-full bg-[#c0d5fd]/60 flex items-center justify-center relative">
              <div
                className={`w-12 h-12 rounded-full bg-[#0a6fe8] text-white flex items-center justify-center font-bold text-[11px] transition-transform duration-1000 ${
                  breathPhase === 'Inhale'
                    ? 'scale-110'
                    : breathPhase === 'Hold'
                    ? 'scale-105'
                    : 'scale-90'
                }`}
              >
                {breathPhase}
              </div>
            </div>
          </div>

          {/* Immediate Critical First-Aid Actions */}
          <div className="space-y-2.5">
            <h3 className="text-[14px] font-bold text-[#0a2342] uppercase tracking-wider">
              If Heavy Bleeding Is Present:
            </h3>

            <div className="p-3 bg-[#ffdad6]/40 rounded-xl border border-[#ffb4ac]/50 flex items-start gap-2.5">
              <span className="w-6 h-6 rounded-full bg-[#e0403a] text-white flex items-center justify-center text-[12px] font-bold shrink-0 mt-0.5">
                1
              </span>
              <p className="text-[13px] text-[#93000a] leading-relaxed">
                <strong>Direct Unrelenting Pressure:</strong> Press firmly into the wound with clean
                cloth or gauze using full palm force. <em>Do not lift to check.</em>
              </p>
            </div>

            <div className="p-3 bg-[#ffdad6]/40 rounded-xl border border-[#ffb4ac]/50 flex items-start gap-2.5">
              <span className="w-6 h-6 rounded-full bg-[#e0403a] text-white flex items-center justify-center text-[12px] font-bold shrink-0 mt-0.5">
                2
              </span>
              <p className="text-[13px] text-[#93000a] leading-relaxed">
                <strong>Elevate Limb:</strong> If possible, lift the bleeding arm or leg above heart
                level while maintaining heavy compression.
              </p>
            </div>

            <div className="p-3 bg-[#ffdad6]/40 rounded-xl border border-[#ffb4ac]/50 flex items-start gap-2.5">
              <span className="w-6 h-6 rounded-full bg-[#e0403a] text-white flex items-center justify-center text-[12px] font-bold shrink-0 mt-0.5">
                3
              </span>
              <p className="text-[13px] text-[#93000a] leading-relaxed">
                <strong>Layering:</strong> If blood soaks through, add more cloth on top. Never peel
                off soaked bottom layers to protect forming clots.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f7fafe] border-t border-[#e2e8f0]">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 bg-[#ebeef2] hover:bg-[#e0e3e7] text-[#0a2342] font-bold text-[14px] rounded-full transition-colors cursor-pointer"
          >
            I Understand / Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
