export type ScreenId =
  | 'home'
  | 'scanner-live-view'
  | 'result'
  | 'pair-device'
  | 'device-settings'
  | 'wound-history'
  | 'first-aid-guide';

export interface DeviceState {
  name: string;
  serialNumber: string;
  firmware: string;
  battery: number;
  isConnected: boolean;
  signalStrength: string;
  ringLightBrightness: 30 | 65 | 100;
  isLedOn: boolean;
  autoSleepMinutes: number;
  singlePressAction: string;
  doublePressAction: string;
  opticalMagnification: '10x' | '20x' | '40x';
}

export interface WoundRecord {
  id: string;
  title: string;
  category: string;
  matchScore: number;
  depthType: string;
  dimensions: string;
  area: string;
  depth: string;
  severityTier: 'Tier 1/3' | 'Tier 2/3' | 'Tier 3/3';
  severityLabel: string;
  timestamp: string;
  healedPercent: number;
  imageUrl: string;
  clinicalNotes: string;
  status: 'Healed' | 'Healing' | 'Monitoring' | 'Attention';
  treatmentSteps: {
    id: number;
    title: string;
    description: string;
    completed: boolean;
    hasTimer?: boolean;
    timerSeconds?: number;
    timerLabel?: string;
  }[];
}

export interface KitItem {
  id: string;
  name: string;
  category: string;
  inStock: boolean;
  quantity: string;
  recommended: string;
}

export interface ProtocolGuide {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  summary: string;
  steps: string[];
  cautions: string[];
}
