/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BottomNav } from './components/BottomNav';
import { DeviceSettingsScreen } from './components/DeviceSettingsScreen';
import { EmergencyModal } from './components/EmergencyModal';
import { FirstAidGuideScreen } from './components/FirstAidGuideScreen';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { LensCareModal } from './components/LensCareModal';
import { NurseAiModal } from './components/NurseAiModal';
import { PairDeviceScreen } from './components/PairDeviceScreen';
import { PhoneCameraModal } from './components/PhoneCameraModal';
import { ScannerLiveView } from './components/ScannerLiveView';
import { ScanResultScreen } from './components/ScanResultScreen';
import { WoundHistoryScreen } from './components/WoundHistoryScreen';
import { INITIAL_DEVICE_STATE, INITIAL_WOUND_RECORDS } from './data/mockData';
import { DeviceState, ScreenId, WoundRecord } from './types';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('home');
  const [screenHistory, setScreenHistory] = useState<ScreenId[]>(['home']);
  const [deviceState, setDeviceState] = useState<DeviceState>(INITIAL_DEVICE_STATE);
  const [wounds, setWounds] = useState<WoundRecord[]>(INITIAL_WOUND_RECORDS);
  const [activeWound, setActiveWound] = useState<WoundRecord>(INITIAL_WOUND_RECORDS[0]);
  const [selectedProtocolId, setSelectedProtocolId] = useState<string>('first-aid-basics');

  // Modals state
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isNurseAiOpen, setIsNurseAiOpen] = useState(false);
  const [isPhoneCameraOpen, setIsPhoneCameraOpen] = useState(false);
  const [lensCareModalType, setLensCareModalType] = useState<
    'cleaning' | 'calibration' | 'help' | null
  >(null);

  // Desktop Mobile Frame Toggle
  const [isPhoneFrameMode, setIsPhoneFrameMode] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const navigateTo = (screen: ScreenId) => {
    setScreenHistory((prev) => [...prev, screen]);
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    if (screenHistory.length > 1) {
      const nextHistory = [...screenHistory];
      nextHistory.pop();
      const prevScreen = nextHistory[nextHistory.length - 1];
      setScreenHistory(nextHistory);
      setCurrentScreen(prevScreen || 'home');
    } else {
      setCurrentScreen('home');
    }
  };

  const updateDeviceState = (updates: Partial<DeviceState>) => {
    setDeviceState((prev) => {
      const next = { ...prev, ...updates };
      return next;
    });
    if (updates.isConnected === false) {
      showToast('Mendly Scanner Disconnected');
    } else if (updates.isConnected === true) {
      showToast('Mendly Scanner Pro Connected via BLE 5.2');
    }
  };

  const handleSaveToWounds = (woundToSave: WoundRecord) => {
    setWounds((prev) => {
      const exists = prev.some((w) => w.id === woundToSave.id);
      if (exists) {
        return prev.map((w) => (w.id === woundToSave.id ? woundToSave : w));
      }
      return [woundToSave, ...prev];
    });
    showToast('Saved to My Wounds! Tracked in History.');
  };

  const handleSelectProtocol = (protocolId: string) => {
    setSelectedProtocolId(protocolId);
    navigateTo('first-aid-guide');
  };

  const handleInspectWound = (wound: WoundRecord) => {
    setActiveWound(wound);
    navigateTo('result');
  };

  const getScreenTitle = (): string => {
    switch (currentScreen) {
      case 'pair-device':
        return 'Pair Device';
      case 'device-settings':
        return 'Device Settings';
      case 'result':
        return 'Result';
      case 'wound-history':
        return 'Wound History';
      case 'first-aid-guide':
        return 'First Aid & Kit';
      default:
        return 'Mendly';
    }
  };

  const isTabScreen =
    currentScreen === 'home' ||
    currentScreen === 'wound-history' ||
    currentScreen === 'first-aid-guide';

  return (
    <div className="min-h-screen bg-[#f1f4f8] text-[#0a2342] flex flex-col items-center justify-start antialiased selection:bg-[#0a6fe8]/20">
      {/* Desktop Top Demo Switcher Toolbar */}
      <div className="w-full bg-white/90 backdrop-blur-md border-b border-[#e2e8f0] py-2 px-4 flex items-center justify-between z-30 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#0a6fe8] animate-pulse" />
          <span className="text-[13px] font-bold text-[#0a2342]">
            Mendly Mobile Dermatoscope Experience
          </span>
        </div>

        {/* Screen Quick Jumper Tabs for Convenience */}
        <div className="hidden lg:flex items-center gap-1 bg-[#ebeef2] p-1 rounded-full text-[12px]">
          {(
            [
              { id: 'home', label: 'Home' },
              { id: 'scanner-live-view', label: 'Live Scanner' },
              { id: 'result', label: 'Analysis Result' },
              { id: 'pair-device', label: 'Pair Device' },
              { id: 'device-settings', label: 'Device Settings' },
              { id: 'wound-history', label: 'History' },
              { id: 'first-aid-guide', label: 'First Aid' },
            ] as const
          ).map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => navigateTo(s.id as ScreenId)}
              className={`px-3 py-1 rounded-full font-bold transition-all cursor-pointer ${
                currentScreen === s.id
                  ? 'bg-[#0a6fe8] text-white shadow-xs'
                  : 'text-[#414754] hover:text-[#0a2342]'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        {/* Frame Toggle */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPhoneFrameMode(!isPhoneFrameMode)}
            className="text-[12px] font-bold px-3 py-1.5 rounded-full bg-[#f1f4f8] hover:bg-[#e0e3e7] text-[#0a2342] flex items-center gap-1.5 transition-colors cursor-pointer border border-[#e2e8f0]"
            title="Toggle between phone chassis mockup and full window view"
          >
            <span className="material-symbols-outlined text-[16px]">
              {isPhoneFrameMode ? 'fullscreen' : 'smartphone'}
            </span>
            <span className="hidden sm:inline">
              {isPhoneFrameMode ? 'Full Width View' : 'Phone Frame'}
            </span>
          </button>
        </div>
      </div>

      {/* Main View Container */}
      <div
        className={`w-full transition-all duration-300 ${
          isPhoneFrameMode
            ? 'max-w-[440px] my-0 sm:my-6 rounded-none sm:rounded-[42px] shadow-none sm:shadow-[0_12px_45px_-8px_rgba(10,35,66,0.18)] border-0 sm:border-[8px] sm:border-[#2d3134] overflow-hidden bg-[#f7fafe] relative min-h-screen sm:min-h-[890px] flex flex-col justify-between'
            : 'w-full bg-[#f7fafe] min-h-screen'
        }`}
      >
        {/* Simulated Phone Dynamic Island / Camera Notch on Desktop Frame */}
        {isPhoneFrameMode && (
          <div className="hidden sm:flex justify-center pt-2 pb-1 bg-white/70 backdrop-blur-md z-50 sticky top-0 border-b border-[#e2e8f0]/40">
            <div className="w-24 h-4 bg-[#181c1f] rounded-full flex items-center justify-end px-2">
              <span className="w-2 h-2 rounded-full bg-[#2d3134]" />
            </div>
          </div>
        )}

        {/* Top Header (shown on non-live-view screens) */}
        {currentScreen !== 'scanner-live-view' && (
          <Header
            currentScreen={currentScreen}
            title={getScreenTitle()}
            onBack={handleBack}
            onOpenEmergency={() => setIsEmergencyOpen(true)}
            onOpenHelp={() => setLensCareModalType('help')}
            onNavigateToDeviceSettings={() => navigateTo('device-settings')}
            isPairingConnected={deviceState.isConnected}
          />
        )}

        {/* Screen Routing */}
        <main className="flex-1 w-full relative">
          {currentScreen === 'home' && (
            <HomeScreen
              deviceState={deviceState}
              wounds={wounds}
              onNavigate={navigateTo}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
              onSelectProtocol={handleSelectProtocol}
              onUsePhoneCamera={() => setIsPhoneCameraOpen(true)}
              onInspectWound={handleInspectWound}
            />
          )}

          {currentScreen === 'scanner-live-view' && (
            <ScannerLiveView
              deviceState={deviceState}
              onCapture={() => {
                setActiveWound(INITIAL_WOUND_RECORDS[0]);
                navigateTo('result');
              }}
              onBack={handleBack}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
              onNavigate={navigateTo}
              onUpdateDeviceState={updateDeviceState}
            />
          )}

          {currentScreen === 'result' && (
            <ScanResultScreen
              wound={activeWound}
              onScanAgain={() => navigateTo('scanner-live-view')}
              onSaveToWounds={handleSaveToWounds}
              onOpenNurseAi={() => setIsNurseAiOpen(true)}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
              onNavigate={navigateTo}
            />
          )}

          {currentScreen === 'pair-device' && (
            <PairDeviceScreen
              deviceState={deviceState}
              onUpdateDeviceState={updateDeviceState}
              onNavigate={navigateTo}
              onOpenHelp={() => setLensCareModalType('help')}
            />
          )}

          {currentScreen === 'device-settings' && (
            <DeviceSettingsScreen
              deviceState={deviceState}
              onUpdateDeviceState={updateDeviceState}
              onOpenLensCare={() => setLensCareModalType('cleaning')}
              onOpenCalibration={() => setLensCareModalType('calibration')}
              onNavigate={navigateTo}
            />
          )}

          {currentScreen === 'wound-history' && (
            <WoundHistoryScreen
              wounds={wounds}
              onSelectWound={handleInspectWound}
              onNavigate={navigateTo}
            />
          )}

          {currentScreen === 'first-aid-guide' && (
            <FirstAidGuideScreen
              initialProtocolId={selectedProtocolId}
              onNavigate={navigateTo}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
            />
          )}
        </main>

        {/* Bottom Tab Bar (shown when on main tab destinations) */}
        {isTabScreen && (
          <BottomNav currentScreen={currentScreen} onNavigate={navigateTo} />
        )}
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-24 z-50 px-4 py-2.5 rounded-full bg-[#0a2342] text-white text-[13px] font-bold shadow-xl border border-white/20 animate-fade-in flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-[#10b981]">
            check_circle
          </span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modals */}
      <NurseAiModal
        isOpen={isNurseAiOpen}
        onClose={() => setIsNurseAiOpen(false)}
        onOpenEmergency={() => {
          setIsNurseAiOpen(false);
          setIsEmergencyOpen(true);
        }}
      />

      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />

      <LensCareModal
        type={lensCareModalType}
        onClose={() => setLensCareModalType(null)}
      />

      <PhoneCameraModal
        isOpen={isPhoneCameraOpen}
        onClose={() => setIsPhoneCameraOpen(false)}
        onAnalysisComplete={(analyzedWound) => {
          setIsPhoneCameraOpen(false);
          setActiveWound(analyzedWound);
          navigateTo('result');
        }}
      />
    </div>
  );
}
